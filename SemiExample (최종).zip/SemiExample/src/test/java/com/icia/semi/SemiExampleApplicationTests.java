package com.icia.semi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
