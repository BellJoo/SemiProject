
// const IMP = window.IMP;
if (IMP) {
    IMP.init('imp27151828');
}

const button = document.getElementById("payButton");

const onClickPay = () => {
    IMP.request_pay({
            pg: "naverpay",
            pay_method: "card",
            amount: "2500",
            name: "매운라면",
            merchant_uid: "ORD20241107-000001",
            buyer_email: "11111@outlook.com",
            buyer_name: "김구매자",
            buyer_tel: "010-1234-5678",
            buyer_addr: "서울특별시 강남구 삼성동",
            buyer_postcode: "123-456",
        },
        function (response) {
            const { status, err_msg } = response;
            if (err_msg) {
                alert(`결제 실패: ${err_msg}`);
            }
            if (status === "paid") {
                const { imp_uid } = response;
                verifyPayment(imp_uid);
            }
        });
};

// 버튼에 클릭 이벤트 리스너 추가
button.addEventListener("click", onClickPay);
