//package com.icia.semi.controller;
//
//import ch.qos.logback.core.model.Model;
//import com.icia.semi.dao.AdminRepository;
//import com.icia.semi.dto.*;
//import com.icia.semi.service.AdminService;
//import jakarta.servlet.http.HttpSession;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.ModelAndView;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@Controller
//@RequiredArgsConstructor
//public class AdminController {
//    private final AdminService asvc;
///*    private final MemberService msvc;
//    private final ReportService rsvc;*/
//
//    private final AdminRepository arepo;
//    private final HttpSession session;
//
//    // 관리자 회원가입 페이지로 이동
//    // 관리자 회원가입 페이지로 이동
//    @GetMapping("/adminJoinForm")
//    public ModelAndView adminJoinForm() {
//        ModelAndView mav = new ModelAndView();
//        boolean isSuperAdminExists = asvc.isSuperAdminExists();  // 최고 관리자 존재 여부 확인
//        mav.addObject("isSuperAdminExists", isSuperAdminExists);  // 최고 관리자 존재 여부를 모델에 추가
//        mav.setViewName("admin/adminJoin");  // 회원가입 페이지로 이동
//        return mav;
//    }
//
//
//    // 관리자 회원가입 처리
//    @PostMapping("/adminJoin")
//    public ModelAndView adminJoin(@ModelAttribute AdminDTO admin) {
//
//        return asvc.adminJoin(admin);  // 서비스에서 회원가입 처리
//    }
//
//    // 관리자 로그인 페이지
//    @GetMapping("adminLoginForm")
//    public String adminLoginForm() {
//        return "admin/adminLogin";
//    }
//
//    // 관리자 로그인 처리
//    @PostMapping("/adminLogin")
//    public ModelAndView adminLogin(@ModelAttribute AdminDTO admin) {
//        ModelAndView mav = asvc.adminLogin(admin);
//        if (mav.getViewName().equals("redirect:/Admin")) {
//            session.setAttribute("loginId", admin.getAdminId());  // 로그인 시 세션에 로그인 아이디 저장
//        }
//        return mav;
//    }
//
//
//    @GetMapping("/mLogout")
//    public String mLogout(HttpSession session){
//        session.invalidate();
//        return "redirect:/index";
//    }
//
//
//
//    @GetMapping("/Admin")
//    public ModelAndView Admin() {
//        ModelAndView mav = new ModelAndView();
//
//        String loginId = (String) session.getAttribute("loginId");
//        if (loginId == null) {
//            mav.setViewName("admin/adminLogin");  // 로그인되지 않으면 로그인 페이지로 리다이렉트
//            return mav;
//        }
//
//        // 세션에서 관리 권한을 가져옴 (String 타입으로 관리 권한 체크)
//        String adminInquiries = (String) session.getAttribute("adminInquiries");
//        String adminNotices = (String) session.getAttribute("adminNotices");
//        String adminEvents = (String) session.getAttribute("adminEvents");
//        String adminReports = (String) session.getAttribute("adminReports");
//
//        // 권한 값들을 모델에 추가
//        mav.addObject("loginId", loginId);
//        mav.addObject("adminInquiries", adminInquiries);
//        mav.addObject("adminNotices", adminNotices);
//        mav.addObject("adminEvents", adminEvents);
//        mav.addObject("adminReports", adminReports);
//
//        mav.setViewName("redirect:/Admin");  // 관리자 대시보드 페이지로 이동
//
//        return mav;
//    }
//    //------------------------------------------------
//
//    // 관리자 목록 가져오기 API
//    @GetMapping("/getAllAdmins")
//    @ResponseBody
//    public List<AdminDTO> getAllAdmins() {
//        List<AdminEntity> admins = arepo.findAll();  // 관리자 목록을 모두 가져옵니다.
//        List<AdminDTO> adminDTOList = new ArrayList<>();
//
//        for (AdminEntity adminEntity : admins) {
//            AdminDTO adminDTO = AdminDTO.toDTO(adminEntity);
//            adminDTOList.add(adminDTO);
//        }
//
//        return adminDTOList;
//    }
//
//
//    // 관리자 권한 부여 페이지
//    @GetMapping("/adminGrantPermissions")
//    public ModelAndView adminGrantPermissions() {
//        List<AdminDTO> admins = asvc.getAllAdmins();  // 관리자 목록 가져오기
//        ModelAndView modelAndView = new ModelAndView("admin/adminGrantPermissions");
//        modelAndView.addObject("admins", admins);  // 모델에 관리자 목록 추가
//        return modelAndView;
//    }
//
//    // 특정 관리자의 권한 상태를 가져오는 API
//    @GetMapping("/getAdminPermissions")
//    @ResponseBody
//    public Map<String, String> getAdminPermissions(@RequestParam String adminId) {
//        return asvc.getAdminPermissions(adminId);
//    }
//
//
//
//    // 각 메뉴 접근 시 권한 체크
//    @GetMapping("/adminInquiries")
//    public ModelAndView adminInquiries() {
//        return checkPermission("inquiries");
//    }
//
//    @GetMapping("/adminNotices")
//    public ModelAndView adminNotices() {
//        return checkPermission("notices");
//    }
//
//    @GetMapping("/adminEvents")
//    public ModelAndView adminEvents() {
//        return checkPermission("events");
//    }
//
//    @GetMapping("/adminReports")
//    public ModelAndView adminReports() {
//        return checkPermission("reports");
//    }
//
//    // 권한을 체크하는 공통 메서드
//    private ModelAndView checkPermission(String menuName) {
//        ModelAndView mav = new ModelAndView();
//
//        // 세션에서 권한 정보 확인
//        String manageInquiries = (String) session.getAttribute("manageInquiries"); // 오타 가능성 있음
//        String manageNotices = (String) session.getAttribute("manageNotices");
//        String manageEvents = (String) session.getAttribute("manageEvents");
//        String manageReports = (String) session.getAttribute("manageReports");
//
//        // 각 메뉴에 대한 권한 확인
//        switch (menuName) {
//            case "inquiries":
//                if (!manageInquiries.equals("Y")) {
//                    mav.addObject("error", "문의사항 관리 권한이 없습니다.");
//                    mav.setViewName("redirect:/Admin");
//                } else {
//                    mav.setViewName("admin/inquiries");
//                }
//                break;
//
//            case "notices":
//                System.out.println("manageNotices: " + manageNotices);
//                if (!manageNotices.equals("Y")) {
//                    mav.addObject("error", "공지사항 관리 권한이 없습니다.");
//                    mav.setViewName("redirect:/Admin");
//                } else {
//                    mav.setViewName("notice/noticeIndex");
//                }
//                break;
//
//            case "events":
//                System.out.println("manageEvents : " + manageEvents);
//                if (!manageEvents.equals("Y")) {
//                    mav.addObject("error", "이벤트 관리 권한이 없습니다.");
//                    mav.setViewName("redirect:/Admin");
//                } else {
//                    mav.setViewName("admin/events");
//                }
//                break;
//
//            case "reports":
//                if (!manageReports.equals("Y")) {
//                    mav.addObject("error", "신고 관리 권한이 없습니다.");
//                    mav.setViewName("redirect:/Admin");
//                } else {
//                    mav.setViewName("admin/reports");
//                }
//                break;
//
//            default:
//                mav.setViewName("redirect:/Admin");
//                break;
//        }
//
//        return mav;
//    }
//    // 관리자 권한 부여
//  /*  @PostMapping("/grantAdminPermissions")
//    public ResponseEntity<Map<String, String>> grantAdminPermissions(@RequestBody AdminDTO adminDTO) {
//        // 권한 부여 로직 처리
//        String result = asvc.grantPermissions(adminDTO.getAdminId(), adminDTO.getManageInquiries(),
//                adminDTO.getManageNotices(), adminDTO.getManageEvents(),
//                adminDTO.getManageReports());
//
//        Map<String, String> response = new HashMap<>();
//        response.put("message", result);
//
//        if (result.equals("권한 부여 성공")) {
//            return ResponseEntity.ok(response);
//        } else {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
//        }
//    }
//    @PostMapping("/admin/permissions")
//    public ResponseEntity<Void> grantAdminPermissions(@RequestParam String adminId,
//                                                      @RequestParam String manageInquiries,
//                                                      @RequestParam String manageNotices,
//                                                      @RequestParam String manageEvents,
//                                                      @RequestParam String manageReports) {
//        try {
//            AdminEntity adminEntity = arepo.findByAdminId(adminId);
//            if (adminEntity != null) {
//                adminEntity.setManageInquiries(manageInquiries);
//                adminEntity.setManageNotices(manageNotices);
//                adminEntity.setManageEvents(manageEvents);
//                adminEntity.setManageReports(manageReports);
//
//                arepo.save(adminEntity);
//                return ResponseEntity.ok().build();  // 성공 시 200 OK 응답만 반환
//            } else {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();  // 어드민을 찾지 못한 경우 404 응답
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();  // 실패 시 500 응답
//        }
//    }*/
//    @PostMapping("/admin/permissions")
//    public ResponseEntity<Map<String, String>> grantAdminPermissions(@RequestBody AdminDTO adminDTO) {
//        try {
//            if (adminDTO == null || adminDTO.getAdminId() == null) {
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", "잘못된 데이터 형식"));
//            }
//
//            // 권한 부여 로직
//            String result = asvc.grantPermissions(
//                    adminDTO.getAdminId(),
//                    adminDTO.getManageInquiries(),
//                    adminDTO.getManageNotices(),
//                    adminDTO.getManageEvents(),
//                    adminDTO.getManageReports()
//            );
//
//            Map<String, String> response = new HashMap<>();
//            response.put("message", result);
//
//            if (result.equals("권한 부여 성공")) {
//                return ResponseEntity.ok(response);
//            } else {
//                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("message", "서버 오류"));
//        }
//    }
//
//    /*----------결합 본---------*/
//    @GetMapping("/admin/Admin")
//    public ModelAndView adminPage() {
//        ModelAndView mav = new ModelAndView();
//
//        // 세션에서 로그인된 사용자 ID 확인
//        String loginId = (String) session.getAttribute("loginId");
//
//        // 로그인된 아이디가 admin이 아니면 접근 차단
//        if (loginId == null || !loginId.equals("admin")) {
//            mav.setViewName("redirect:/loginForm");  // 로그인 페이지로 리다이렉트
//            mav.addObject("error", "관리자 권한이 필요합니다.");
//            return mav;
//        }
//
//        // 회원 목록 가져오기
//        List<MemberDTO> userList = asvc.getAllMembers();
//        mav.addObject("userList", userList);
//
//        // 신고 목록 가져오기
//        List<ReportDTO> reportList = asvc.getAllReports();
//        mav.addObject("reportList", reportList);
//
//        //문의 목록 가져오기
//        List<BoardDTO> inquiryList = asvc.getInquiries(); // 문의사항 게시글 리스트 가져오기
//        mav.addObject("inquiryList", inquiryList);
//
//        mav.setViewName("admin/Admin");  // 관리자 페이지로 이동
//        return mav;
//    }
//
//    // 권한 파트 시도중
//    @PostMapping("/admin/blockUser")
//    @ResponseBody
//    public ResponseEntity<String> blockUser(@RequestParam String memberId) {
//        System.out.println("블록 요청 받은 회원 ID: " + memberId); // 디버그 로그
//
//        boolean isBlocked = asvc.blockUser(memberId);
//
//        if (isBlocked) {
//            System.out.println("회원 차단 성공: " + memberId);
//            return ResponseEntity.ok("success");
//        } else {
//            System.out.println("회원 차단 실패 (존재하지 않는 회원): " + memberId);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("회원이 존재하지 않습니다.");
//        }
//    }
//
//
//    @PostMapping("/markReportAsCompleted")
//    @ResponseBody
//    public ResponseEntity<String> markReportAsCompleted(@RequestParam Long reportId) {
//        boolean isCompleted = asvc.markReportAsCompleted(reportId);
//        if (isCompleted) {
//            return ResponseEntity.ok("success");
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("신고가 존재하지 않습니다.");
//        }
//    }
//
//    @PostMapping("/admin/toggleUserBlockStatus")
//    @ResponseBody
//    public ResponseEntity<String> toggleUserBlockStatus(@RequestParam String memberId) {
//        System.out.println("회원 상태 토글 요청 받은 ID: " + memberId);
//
//        boolean isToggled = asvc.toggleUserBlockStatus(memberId);
//
//        if (isToggled) {
//            return ResponseEntity.ok("success");
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("회원이 존재하지 않습니다.");
//        }
//    }
//
//}




package com.icia.semi.controller;

import com.icia.semi.dto.BoardDTO;
import com.icia.semi.dto.MemberDTO;
import com.icia.semi.dto.ReportDTO;
import com.icia.semi.service.AdminService;
import com.icia.semi.service.MemberService;
import com.icia.semi.service.ReportService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequiredArgsConstructor

public class AdminController {

    private final AdminService asvc;
    private final HttpSession session;

    private final MemberService msvc;
    private final ReportService rsvc;

    @GetMapping("/admin/Admin")
    public ModelAndView adminPage(Model model) {
        ModelAndView mav = new ModelAndView();

        // 세션에서 로그인된 사용자 ID 확인
        String loginId = (String) session.getAttribute("loginId");

        // 로그인된 아이디가 admin이 아니면 접근 차단
        if (loginId == null || !loginId.equals("admin")) {
            mav.setViewName("redirect:/loginForm");  // 로그인 페이지로 리다이렉트
            mav.addObject("error", "관리자 권한이 필요합니다.");
            return mav;
        }

        // 회원 목록 가져오기
        List<MemberDTO> userList = asvc.getAllMembers();
        model.addAttribute("userList", userList);

        // 신고 목록 가져오기
        List<ReportDTO> reportList = asvc.getAllReports();
        model.addAttribute("reportList", reportList);

        //문의 목록 가져오기
        List<BoardDTO> inquiryList = asvc.getInquiries(); // 문의사항 게시글 리스트 가져오기
        model.addAttribute("inquiryList", inquiryList);

        mav.setViewName("admin/Admin");  // 관리자 페이지로 이동
        return mav;
    }



    // 권한 파트 시도중
    @PostMapping("/admin/blockUser")
    @ResponseBody
    public ResponseEntity<String> blockUser(@RequestParam String memberId) {
        System.out.println("블록 요청 받은 회원 ID: " + memberId); // 디버그 로그

        boolean isBlocked = asvc.blockUser(memberId);

        if (isBlocked) {
            System.out.println("회원 차단 성공: " + memberId);
            return ResponseEntity.ok("success");
        } else {
            System.out.println("회원 차단 실패 (존재하지 않는 회원): " + memberId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("회원이 존재하지 않습니다.");
        }
    }


    @PostMapping("/admin/markReportAsCompleted")
    @ResponseBody
    public ResponseEntity<String> markReportAsCompleted(@RequestParam Long reportId) {
        boolean isCompleted = asvc.markReportAsCompleted(reportId);
        if (isCompleted) {
            return ResponseEntity.ok("success");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("신고가 존재하지 않습니다.");
        }
    }

    @PostMapping("/admin/toggleUserBlockStatus")
    @ResponseBody
    public ResponseEntity<String> toggleUserBlockStatus(@RequestParam String memberId) {
        System.out.println("회원 상태 토글 요청 받은 ID: " + memberId);

        boolean isToggled = asvc.toggleUserBlockStatus(memberId);

        if (isToggled) {
            return ResponseEntity.ok("success");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("회원이 존재하지 않습니다.");
        }
    }



}

