package com.icia.semi.controller;

import com.icia.semi.dto.BoardDTO;
import com.icia.semi.dto.SearchDTO;
import com.icia.semi.service.BoardService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardService bsvc;
    private final HttpSession session;

    // WrtieForm : 게시글 작성 페이지로 이동
    @GetMapping("/writeForm")
    public String writeForm() {

        if(session.getAttribute("loginId") == null) {
            return "member/login";
        } else {
            return "board/write";
        }
    }

    //Write : 게시글 작성
//    @PostMapping("/Write")
//    public ModelAndView bWrite(@ModelAttribute BoardDTO board){
//        System.out.println("\n게시글 작성 메소드\n[1]html → controller : " + board);
//        return bsvc.bWrite(board);
//    }


    //Write : 게시글 작성
    @PostMapping("/Write")
    public ModelAndView bWrite(@ModelAttribute BoardDTO board, @ModelAttribute SearchDTO search){
        System.out.println("\n게시글 작성 메소드\n[1]html → controller : " + board);
        System.out.println("\n카테고리 및 키워드 : " + search);


        if(search.getCategory() != null && !search.getCategory().isEmpty()){
            board.setCategory(search.getCategory());
        } else {
            board.setCategory("자유게시판");
        }
        return bsvc.bWrite(board);
    }


    // bList : 게시글 목록
    @GetMapping("/bList")
    public String bList(){
        return "board/list";
    }



    // bView : 게시글 상세보기
    @GetMapping("/bView/{boardId}")
    public ModelAndView bView(@PathVariable int boardId){
        return bsvc.bView(boardId);
    }

    // bModify : 게시글 수정
    @PostMapping("/bModify")
    public ModelAndView bModify(@ModelAttribute BoardDTO board){
        return bsvc.bModify(board);

    }

    // bDelete : 게시글 삭제
    @GetMapping("/bDelete")
    public ModelAndView bDelete(@ModelAttribute BoardDTO board){
        return bsvc.bDelete(board);
    }



}
