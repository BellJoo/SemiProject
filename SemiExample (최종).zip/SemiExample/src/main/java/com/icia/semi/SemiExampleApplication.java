package com.icia.semi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication(scanBasePackages = "com.icia.semi")
public class SemiExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemiExampleApplication.class, args);
	}

    @Bean
    public RestTemplate restTemplate() {
        System.out.println("RestTemplate 빈 생성됨");
        return new RestTemplate();
    }
}
