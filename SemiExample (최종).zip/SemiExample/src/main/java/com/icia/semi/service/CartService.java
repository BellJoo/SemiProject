package com.icia.semi.service;

import com.icia.semi.dto.CartItemDTO;
import com.icia.semi.dto.ProductDTO;
import com.icia.semi.dao.CartRepository;
import com.icia.semi.dao.MemberRepository;
import com.icia.semi.dao.ProductRepository;
import com.icia.semi.dto.CartEntity;
import com.icia.semi.dto.MemberEntity;
import com.icia.semi.dto.ProductEntity;
import jakarta.transaction.Transactional;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final MemberRepository memberRepository;

    public CartService(CartRepository cartRepository, ProductRepository productRepository, MemberRepository memberRepository) {
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.memberRepository = memberRepository;
    }

    /**
     * 장바구니에 상품 추가
     * - 같은 상품이 이미 장바구니에 있으면 수량 증가
     * - 없는 경우 새로운 항목 추가
     */
    @Transactional
    public boolean addToCart(String memberId, ProductDTO productDTO) {
        // 회원 및 상품 확인
        MemberEntity member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("회원 정보를 찾을 수 없습니다. (ID: " + memberId + ")"));
        ProductEntity product = productRepository.findById(productDTO.getProductId())
                .orElseThrow(() -> new IllegalArgumentException("상품 정보를 찾을 수 없습니다. (ID: " + productDTO.getProductId() + ")"));

        // 기존 장바구니 항목 확인
        Optional<CartEntity> existingCart = cartRepository.findByMember_MemberIdAndProduct_ProductId(memberId, productDTO.getProductId());

        if (existingCart.isPresent()) {
            // 기존 항목이 있으면 수량 증가
            CartEntity cartEntity = existingCart.get();
            cartEntity.setQuantity(cartEntity.getQuantity() + productDTO.getQuantity());
            cartRepository.save(cartEntity);
        } else {
            // 새로운 항목 추가
            CartEntity newCartEntity = new CartEntity();
            newCartEntity.setMember(member);
            newCartEntity.setProduct(product);
            newCartEntity.setQuantity(productDTO.getQuantity());
            cartRepository.save(newCartEntity);
        }
        return true;
    }

    /**
     * 회원의 장바구니 목록 가져오기
     */
    @Transactional
    public List<CartItemDTO> getCartItems(String memberId) {
        // 회원의 장바구니 항목 검색 및 변환
        return cartRepository.findByMember_MemberId(memberId).stream()
                .peek(cart -> Hibernate.initialize(cart.getProduct())) // Lazy 로딩 초기화
                .map(cart -> new CartItemDTO(
                        cart.getProduct().getProductId(),
                        cart.getProduct().getPname(),
                        cart.getProduct().getPrice(),
                        cart.getProduct().getCoverImage(),
                        cart.getQuantity()
                ))
                .collect(Collectors.toList());
    }

    /**
     * 장바구니 항목 수량 업데이트
     */
    @Transactional
    public boolean updateQuantity(String productId, int quantity) {
        CartEntity cart = cartRepository.findByProductProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("장바구니 항목을 찾을 수 없습니다. (Product ID: " + productId + ")"));

        if (quantity > 0) {
            cart.setQuantity(quantity);
            cartRepository.save(cart);
        } else {
            cartRepository.delete(cart); // 수량이 0 이하인 경우 삭제
        }
        return true;
    }

    /**
     * 장바구니 항목 삭제
     */
    @Transactional
    public boolean deleteSelectedItems(String memberId, List<String> productIds) {
        try {
            productIds.forEach(productId -> {
                cartRepository.deleteByMember_MemberIdAndProduct_ProductId(memberId, productId);
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 선택된 장바구니 항목 결제
     */
    @Transactional
    public boolean checkout(List<CartItemDTO> selectedItems) {
        if (selectedItems == null || selectedItems.isEmpty()) {
            throw new IllegalArgumentException("선택된 결제 항목이 없습니다.");
        }

        try {
            selectedItems.forEach(item -> {
                CartEntity cart = cartRepository.findByProductProductId(item.getProductId())
                        .orElseThrow(() -> new IllegalArgumentException("장바구니 항목을 찾을 수 없습니다. (Product ID: " + item.getProductId() + ")"));
                cartRepository.delete(cart); // 결제 후 항목 삭제
            });
            return true;
        } catch (Exception e) {
            throw new RuntimeException("결제 처리 중 오류 발생: " + e.getMessage(), e);
        }
    }
}
