package com.icia.semi.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class EventDTO {

    private String Event_Id;        // 이벤트 고유 ID
    private String Admin_Id;        // 작성자 ID
    private String Event_Title;          // 이벤트 제목
    private String Event_Message;        // 이벤트 내용
    private LocalDate Event_StartDate;   // 이벤트 시작일
    private LocalDate Event_EndDate;     // 이벤트 종료일
    private LocalDate Event_CreatedAt;   // 이벤트 생성일

    public static EventDTO toDTO(EventEntity entity){
        EventDTO dto = new EventDTO();

        dto.setEvent_Id(entity.getEvent_Id());
        dto.setAdmin_Id(entity.getAdmin_Id());
        dto.setEvent_Title(entity.getEvent_Title());
        dto.setEvent_Message(entity.getEvent_Message());
        dto.setEvent_StartDate(entity.getEvent_StartDate());
        dto.setEvent_EndDate(entity.getEvent_EndDate());
        dto.setEvent_CreatedAt(entity.getEvent_CreatedAt());

        return dto;
    }
}
