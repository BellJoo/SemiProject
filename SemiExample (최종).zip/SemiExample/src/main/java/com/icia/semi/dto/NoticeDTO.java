package com.icia.semi.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NoticeDTO {

    private int NoticeId;        // 공지사항 번호
    private String AdminId;         // 작성자 ID
    private String NoticeTitle;           // 공지 제목
    private String NoticeMessage;         // 공지 내용
    private LocalDateTime NoticeCreatedAt; // 작성일

    // Entity를 DTO로 변환하는 메서드
    public static NoticeDTO toDTO(NoticeEntity entity) {
        NoticeDTO dto = new NoticeDTO();

        dto.setNoticeId(entity.getNoticeId()); // Entity에서 noticeId를 가져와 설정
        dto.setAdminId(entity.getAdminId());
        dto.setNoticeTitle(entity.getNoticeTitle());
        dto.setNoticeMessage(entity.getNoticeMessage());
        dto.setNoticeCreatedAt(entity.getNoticeCreatedAt());

        return dto;
    }
}
