package com.icia.semi.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Data
public class BoardDTO {
    private int boardId;                // 게시글 ID
    private String memberId;            // 작성자 ID
    private String title;               // 게시글 제목
    private String content;             // 게시글 내용
    private LocalDateTime createdAt;    // 작성일
    private LocalDateTime updatedAt;    // 수정일
    private int views;                  // 조회수
    private String fileName;            // 첨부 파일명
    private MultipartFile fileData;     // 첨부파일 데이터
    private int likes;                  // 좋아요 수
    private int reportCount;            // 신고 수



    private String category;


    private Boolean isBest = false;     // BEST 여부 기본값 false 설정

    public static BoardDTO toDTO(BoardEntity entity){
        BoardDTO dto = new BoardDTO();

        dto.setBoardId(entity.getBoardId());
        dto.setTitle(entity.getTitle());
        dto.setContent(entity.getContent());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setViews(entity.getViews());
        dto.setFileName(entity.getFileName());
        dto.setLikes(entity.getLikes());
        dto.setReportCount(entity.getReportCount());

        dto.setCategory(entity.getCategory());




        // MemberId 매핑 추가
        if (entity.getMember() != null) {
            dto.setMemberId(entity.getMember().getMemberId());
        }

        return dto;
    }
}

