//package com.icia.semi.service;
//
//import com.icia.semi.dao.InquiryRepository;
//import com.icia.semi.dao.ReportRepository;
//import com.icia.semi.dto.ReportDTO;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//import org.springframework.web.servlet.ModelAndView;
//import com.icia.semi.dto.ReportEntity;
//
//@Service
//@RequiredArgsConstructor
//public class ReportService {
//
//    private final ReportRepository rrepo;
//    ModelAndView mav = new ModelAndView();
//
//    public void saveReport(ReportDTO reportDTO) {
//        ReportEntity reportEntity = ReportEntity.toEntity(reportDTO);
//        rrepo.save(reportEntity);
//    }
//
//
//}


// ReportService.java
package com.icia.semi.service;

import com.icia.semi.dao.ReportRepository;
import com.icia.semi.dto.ReportDTO;
import com.icia.semi.dto.ReportEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {


    private final ReportRepository rrepo;

//    @Transactional
//    public void saveReport(ReportDTO reportDTO) {
//        try {
//            ReportEntity reportEntity = ReportEntity.toEntity(reportDTO);
//            rrepo.save(reportEntity);
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new RuntimeException("신고 저장 중 오류가 발생했습니다.");
//        }
//    }

    @Transactional
    public void saveReport(ReportDTO reportDTO) {
        try {
            if (reportDTO.getReportReason() == null || reportDTO.getReportReason().isEmpty()) {
                reportDTO.setReportReason("기본 신고 사유"); // 기본 값 설정
            }
            ReportEntity reportEntity = ReportEntity.toEntity(reportDTO);
            rrepo.save(reportEntity);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("신고 저장 중 오류가 발생했습니다.");
        }
    }

//    public List<ReportDTO> getAllReports() {
//        List<ReportEntity> reportEntities = rrepo.findAll();
//        return reportEntities.stream()
//                .map(ReportDTO::fromEntity)
//                .collect(Collectors.toList());
//    }

    public void markReportAsCompleted(Long reportId) {
        ReportEntity report = rrepo.findById(reportId)
                .orElseThrow(() -> new RuntimeException("신고가 존재하지 않습니다."));
        report.setReportStatus("완료"); // 상태를 '완료'로 변경
        rrepo.save(report); // 변경 사항 저장
    }
}
