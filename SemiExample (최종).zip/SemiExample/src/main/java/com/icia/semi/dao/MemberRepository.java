package com.icia.semi.dao;

import com.icia.semi.dto.MemberEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepository extends JpaRepository<MemberEntity, String> {

    boolean existsByEmail(String email);
}
