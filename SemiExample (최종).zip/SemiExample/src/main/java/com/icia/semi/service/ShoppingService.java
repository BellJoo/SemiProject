package com.icia.semi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ShoppingService {

    @Value("${naver.api.client-id}")
    private String clientId;

    @Value("${naver.api.client-secret}")
    private String clientSecret;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ShoppingService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Map<String, String>> searchProducts(String query) {
        // 인코딩 제거한 URL
        String url = "https://openapi.naver.com/v1/search/shop.json?query=" + query;
        System.out.println("Request URL: " + url); // 최종 요청 URL 출력

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Naver-Client-Id", clientId);
        headers.set("X-Naver-Client-Secret", clientSecret);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        // API 응답 확인
        System.out.println("API 응답: " + response.getBody());

        List<Map<String, String>> results = new ArrayList<>();
        try {
            JsonNode items = objectMapper.readTree(response.getBody()).get("items");
            if (items.isArray()) {
                for (JsonNode item : items) {
                    Map<String, String> product = new HashMap<>();
                    product.put("title", item.get("title").asText());
                    product.put("link", item.get("link").asText());
                    product.put("image", item.get("image").asText());
                    product.put("price", item.get("lprice").asText());
                    product.put("mallName", item.get("mallName").asText());
                    results.add(product);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return results;
    }
}
