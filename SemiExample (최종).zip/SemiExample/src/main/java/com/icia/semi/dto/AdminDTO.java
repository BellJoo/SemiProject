package com.icia.semi.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Data
public class AdminDTO {
    private String adminUUId;       // 관리자 고유 아이디
    private String adminId;         // 관리자 계정명 (고유 값)
    private String adminPw;         // 암호화된 비밀번호
    private String adminName;       // 관리자 이름
    private String adminEmail;      // 이메일
    private String adminPhone;      // 연락처
    private String adminAddress;    // 주소
    private String isSuperAdmin;    // superadmin 여부 (Y/N)
    private String manageInquiries; // 문의사항 관리 권한 (Y/N)
    private String manageNotices;  // 공지사항 관리 권한 (Y/N)
    private String manageEvents;   // 이벤트 관리 권한 (Y/N)
    private String manageReports;  // 신고 처리 관리 권한 (Y/N)

    private MultipartFile adminProfile; // 프로필 이미지
    private String adminProfileName;    // 프로필 이미지 이름

    // DTO -> Entity 변환 메소드
    public AdminEntity toEntity() {
        AdminEntity entity = new AdminEntity();
        entity.setAdminUUId(this.adminUUId != null ? this.adminUUId : UUID.randomUUID().toString()); // UUID 자동 생성
        entity.setAdminId(this.adminId);
        entity.setAdminPw(this.adminPw);
        entity.setAdminName(this.adminName);
        entity.setAdminEmail(this.adminEmail);
        entity.setAdminPhone(this.adminPhone);
        entity.setAdminAddress(this.adminAddress);
        entity.setAdminProfileName(this.adminProfileName);
        // null 체크 및 기본값 처리
        entity.setIsSuperAdmin(this.isSuperAdmin != null ? this.isSuperAdmin : "N");  // 기본값 처리
        entity.setManageInquiries(this.manageInquiries != null ? this.manageInquiries : "N");  // 기본값 처리
        entity.setManageNotices(this.manageNotices != null ? this.manageNotices : "N");  // 기본값 처리
        entity.setManageEvents(this.manageEvents != null ? this.manageEvents : "N");  // 기본값 처리
        entity.setManageReports(this.manageReports != null ? this.manageReports : "N");  // 기본값 처리
        return entity;
    }

    // Entity -> DTO 변환 메소드
    public static AdminDTO toDTO(AdminEntity entity) {
        AdminDTO dto = new AdminDTO();
        dto.setAdminUUId(entity.getAdminUUId());
        dto.setAdminId(entity.getAdminId());
        dto.setAdminPw(entity.getAdminPw());
        dto.setAdminName(entity.getAdminName());
        dto.setAdminEmail(entity.getAdminEmail());
        dto.setAdminPhone(entity.getAdminPhone());
        dto.setAdminAddress(entity.getAdminAddress());
        dto.setAdminProfileName(entity.getAdminProfileName());
        // null 체크 및 기본값 처리
        dto.setIsSuperAdmin(entity.getIsSuperAdmin() != null ? entity.getIsSuperAdmin() : "N");
        dto.setManageInquiries(entity.getManageInquiries() != null ? entity.getManageInquiries() : "N");  // 기본값 처리
        dto.setManageNotices(entity.getManageNotices() != null ? entity.getManageNotices() : "N");  // 기본값 처리
        dto.setManageEvents(entity.getManageEvents() != null ? entity.getManageEvents() : "N");  // 기본값 처리
        dto.setManageReports(entity.getManageReports() != null ? entity.getManageReports() : "N");  // 기본값 처리
        return dto;
    }
    public static AdminDTO fromEntity(AdminEntity entity) {
        AdminDTO dto = new AdminDTO();
        dto.setAdminUUId(entity.getAdminUUId());
        dto.setAdminId(entity.getAdminId());
        dto.setAdminPw(entity.getAdminPw());
        dto.setAdminName(entity.getAdminName());
        dto.setAdminEmail(entity.getAdminEmail());
        dto.setAdminPhone(entity.getAdminPhone());
        dto.setAdminAddress(entity.getAdminAddress());
        dto.setAdminProfileName(entity.getAdminProfileName());
        // null 체크 및 기본값 처리
        dto.setIsSuperAdmin(entity.getIsSuperAdmin() != null ? entity.getIsSuperAdmin() : "N");
        dto.setManageInquiries(entity.getManageInquiries() != null ? entity.getManageInquiries() : "N");  // 기본값 처리
        dto.setManageNotices(entity.getManageNotices() != null ? entity.getManageNotices() : "N");  // 기본값 처리
        dto.setManageEvents(entity.getManageEvents() != null ? entity.getManageEvents() : "N");  // 기본값 처리
        dto.setManageReports(entity.getManageReports() != null ? entity.getManageReports() : "N");  // 기본값 처리
        return dto;
    }
}

