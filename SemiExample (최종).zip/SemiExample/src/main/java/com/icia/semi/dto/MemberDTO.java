package com.icia.semi.dto;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Data
public class MemberDTO {

    private String memberId;
    private String password;  // 암호화된 비밀번호
    private String name;      // 이름

    @DateTimeFormat(pattern = "yyyy-MM-dd")  // 날짜 형식 지정
    private Date birth;       // 생년월일

    private String gender;    // 성별
    private String email;     // 이메일 (고유 값)
    private String phone;     // 핸드폰 번호
    private String address;   // 주소
    private MultipartFile profile;   // 프로필 이미지 데이터
    private String profileName; // 프로필 이미지 파일 이름
    private String isBlocked; // 차단 여부 ('N', 'Y')
    private Date blockUntil;  // 차단 해제 시각

    // 엔티티에서 DTO로 변환하는 메소드
    public static MemberDTO toDTO(MemberEntity entity) {
        MemberDTO dto = new MemberDTO();

        dto.setMemberId(entity.getMemberId());
        dto.setPassword(entity.getPassword());
        dto.setName(entity.getName());
        dto.setBirth(entity.getBirth());
        dto.setGender(entity.getGender());
        dto.setEmail(entity.getEmail());
        dto.setPhone(entity.getPhone());
        dto.setAddress(entity.getAddress());
        dto.setProfileName(entity.getProfileName());
        dto.setIsBlocked(entity.getIsBlocked());
        dto.setBlockUntil(entity.getBlockUntil());

        return dto;
    }

    // MemberEntity를 MemberDTO로 변환하는 메소드
    public static MemberDTO fromEntity(MemberEntity entity) {
        MemberDTO dto = new MemberDTO();
        dto.setMemberId(entity.getMemberId());
        dto.setName(entity.getName());
        dto.setEmail(entity.getEmail());
        dto.setBirth(entity.getBirth());
        dto.setIsBlocked(entity.getIsBlocked());
        return dto;
    }
}