package com.icia.semi.service;

import com.icia.semi.dto.ExerciseGuideDTO;
import com.icia.semi.dao.ExerciseGuideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExerciseGuideService {

    @Autowired
    private ExerciseGuideRepository exerciseGuideRepository;

    // 특정 운동 부위의 모든 운동 가이드를 가져오는 메서드
    public List<ExerciseGuideDTO> getGuidesByBodyPart(String bodyPart) {
        return exerciseGuideRepository.findByGbodyPart(bodyPart).stream()
                .map(ExerciseGuideDTO::toDTO)
                .collect(Collectors.toList());
    }

    // 특정 운동 가이드의 상세 정보를 가져오는 메서드
    public ExerciseGuideDTO getGuideDetail(String guideId) {
        return exerciseGuideRepository.findByGuideId(guideId)
                .map(ExerciseGuideDTO::toDTO)
                .orElse(null);
    }
}
