package com.icia.semi.dao;

import com.icia.semi.dto.NoticeEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NoticeRepository extends JpaRepository<NoticeEntity, Integer> {
/*
    List<NoticeEntity> findAllByOrderByBNumDesc();

    List<NoticeEntity> findByBTitleContainingOrderByBNumDesc(String keyword);

    List<NoticeEntity> findByBContentContainingOrderByBNumDesc(String keyword);

    //List<NoticeEntity> findByMember_MIdContainingOrderByBNumDesc(String keyword);
*/

    //조 회 수
 /*   @Modifying
    @Transactional
    @Query("UPDATE BoardEntity b Set b.NHit = b.NHit + 1 WHERE b.NHit = :BNum")
    void incrementBHit(@Param("BNum") int BNum);
*/
/*

    List<NoticeEntity> findByMember_MIdContainingOrderByBNumDesc(String keyword);
*/

}
