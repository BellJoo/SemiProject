package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "notices")  // 테이블 이름을 notices로 지정
public class NoticeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notice_seq")
    @SequenceGenerator(name = "notice_seq", sequenceName = "notice_seq", allocationSize = 1)
    @Column(name = "notice_id")
    private int noticeId;        // 공지사항 고유 ID (자동 증가)

    @Column(name = "admin_id")
    private String adminId;      // 작성자 ID

    @Column(name = "title")
    private String noticeTitle;   // 공지 제목

    @Column(name = "message")
    private String noticeMessage; // 공지 내용

    @Column(name = "created_at")
    private LocalDateTime noticeCreatedAt;  // 작성일

    // DTO -> Entity 변환 메서드
    public static NoticeEntity toEntity(NoticeDTO dto) {
        NoticeEntity entity = new NoticeEntity();

        // Entity에 DTO 값을 설정
        entity.setAdminId(dto.getAdminId());
        entity.setNoticeTitle(dto.getNoticeTitle());
        entity.setNoticeMessage(dto.getNoticeMessage());
        entity.setNoticeCreatedAt(dto.getNoticeCreatedAt());

        return entity;
    }
}
