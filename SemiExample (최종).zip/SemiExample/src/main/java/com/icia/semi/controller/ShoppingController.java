package com.icia.semi.controller;

import com.icia.semi.service.ShoppingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

@Controller
public class ShoppingController {

    private final ShoppingService ssvc;

    public ShoppingController(ShoppingService ssvc) {
        this.ssvc = ssvc;
    }

    // 검색 페이지 표시
    @GetMapping("/search")
    public String searchPage() {
        return "search";  // search.html 파일을 렌더링
    }

    // 검색 기능 처리
    @GetMapping("/search/products")
    public String searchProducts(@RequestParam String query, Model model) {
        List<Map<String, String>> results = ssvc.searchProducts(query);  // `query`를 그대로 전달
        model.addAttribute("results", results);
        return "search";
    }



    // AJAX 요청을 처리하여 JSON 형식으로 검색 결과 반환
    @GetMapping("/api/search/products")
    @ResponseBody
    public List<Map<String, String>> searchProductsAjax(@RequestParam String query) {
        return ssvc.searchProducts(query);
    }


}
