package com.icia.semi.controller;

import com.icia.semi.service.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class EventController {

    private final EventService esvc;
}
