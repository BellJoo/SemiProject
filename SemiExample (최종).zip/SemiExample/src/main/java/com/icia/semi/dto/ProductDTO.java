package com.icia.semi.dto;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class ProductDTO {

    private String productId;
    private String pname;
    private String category;
    private double price;
    private int stock;
    private String pimageUrl;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private int quantity = 1;

    public static ProductDTO toDTO(ProductEntity entity) {
        ProductDTO dto = new ProductDTO();
        dto.setProductId(entity.getProductId());
        dto.setPname(entity.getPname());
        dto.setCategory(entity.getCategory());
        dto.setPrice(entity.getPrice());
        dto.setStock(entity.getStock());
        dto.setPimageUrl(entity.getPimageUrl());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        return dto;
    }
}
