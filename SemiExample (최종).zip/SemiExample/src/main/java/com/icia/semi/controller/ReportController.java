package com.icia.semi.controller;

import com.icia.semi.dto.ReportDTO;
import com.icia.semi.service.ReportService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDateTime;

@Controller
@RequiredArgsConstructor
public class ReportController {

    private final ReportService rsvc;

    private final HttpSession session;

    @PostMapping("/report")
    public ResponseEntity<String> submitReport(@RequestBody ReportDTO reportDTO, HttpSession session) {
        try {
            String loginId = (String) session.getAttribute("loginId");
            if (loginId == null) {
                return ResponseEntity.status(403).body("로그인이 필요합니다.");
            }


            reportDTO.setReportMemberId(loginId);


            if (reportDTO.getReportStatus() == null) {
                reportDTO.setReportStatus("검토중입니다." );
            }

            if (reportDTO.getReportCreatedAt() == null) {
                reportDTO.setReportCreatedAt(LocalDateTime.now());
            }

            //저장
            rsvc.saveReport(reportDTO);
            return ResponseEntity.ok("신고가 접수되었습니다.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("신고 제출에 실패하였습니다: " + e.getMessage());
        }
    }


}

