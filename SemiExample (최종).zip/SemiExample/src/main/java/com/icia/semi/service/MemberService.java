package com.icia.semi.service;

import com.icia.semi.dao.MemberRepository;
import com.icia.semi.dto.MemberDTO;
import com.icia.semi.dto.MemberEntity;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Service
@RequiredArgsConstructor
public class MemberService {

    // 레파지토리를 반환하는 메소드
    private final MemberRepository mrepo;

    // 메일 인증
    private final JavaMailSender mailSender;

    // 저장 경로
    Path path = Paths.get(System.getProperty("user.dir"), "src/main/resources/static/profile");

    // 암호화
    private BCryptPasswordEncoder pwEnc = new BCryptPasswordEncoder();

    // 로그인 session
    private final HttpSession session;

    // service 시작시 만들것
    private ModelAndView mav;

    // 아이디 존재여부 체크
    public String idCheck(String mId) {
        String result = "";
        Optional<MemberEntity> entity = mrepo.findById(mId);

        if (entity.isPresent()) {
            result = "NO";
        } else {
            result = "OK";
        }

        return result;
    }

    // 이메일 인증 여부 확인
    public String emailCheck(String email) {
        String uuid = null;

        // 인증번호
        uuid = UUID.randomUUID().toString().substring(0, 8);

        // 이메일 발송
        MimeMessage mail = mailSender.createMimeMessage();

        String message = "<h2>안녕하세요. 헬스짐 인증번호 입니다.</h2>"
                + "<p>인증번호는 <b>" + uuid + "</b> 입니다.</p>";

        try {
            // 이메일 전송 준비
            mail.setSubject("헬스짐 인증번호");
            mail.setText(message, "UTF-8", "html");
            mail.addRecipient(Message.RecipientType.TO, new InternetAddress(email));

            // mailSender.send(mail);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

        return uuid;
    }


    public ModelAndView join(MemberDTO member) {
        System.out.println("[2] controller → service : " + member);
        mav = new ModelAndView();

        // (1) 파일 업로드
        MultipartFile profile = member.getProfile();

        if (!profile.isEmpty()) {
            String uuid = UUID.randomUUID().toString().substring(0, 8);
            String fileName = profile.getOriginalFilename();
            String profileName = uuid + "_" + fileName;

            member.setProfileName(profileName);

            String savePath = path + "\\" + profileName;
            System.out.println("savePath : " + savePath);


            try {
                profile.transferTo(new File(savePath));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

        // (2) 비밀번호 암호화
        member.setPassword(pwEnc.encode(member.getPassword()));

        System.out.println("암호화 이후 : " + member);

        // (3) dto(MemberDTO) → entity(MemberEntity)
        MemberEntity entity = MemberEntity.toEntity(member);

        // (4) db저장
        try {
            mrepo.save(entity);
            mav.setViewName("redirect:/index");
        } catch (Exception e) {
            mav.setViewName("redirect:/joinForm");
            throw new RuntimeException(e);
        }

        return mav;
    }


    public ModelAndView view(String memberId) {
        System.out.println("[2] controller → service : " + memberId);
        mav = new ModelAndView();

        Optional<MemberEntity> entity = mrepo.findById(memberId);

        if (entity.isPresent()) {
            MemberDTO member = MemberDTO.toDTO(entity.get());
            mav.addObject("view", member);
            mav.setViewName("member/view");
        } else {
            mav.setViewName("redirect:/list");
        }

        return mav;
    }

    public ModelAndView mModify(MemberDTO member) {
        System.out.println("[2] controller → service : " + member);
        mav = new ModelAndView();

        // (1) 기존 엔티티 가져오기
        MemberEntity existingEntity = mrepo.findById(member.getMemberId())
                .orElseThrow(() -> new RuntimeException("해당 회원을 찾을 수 없습니다."));

        // (2) 고유 제약 조건 체크
        if (!existingEntity.getEmail().equals(member.getEmail()) && mrepo.existsByEmail(member.getEmail())) {
            throw new RuntimeException("이미 존재하는 이메일입니다.");
        }

        // (3) 프로필 업데이트
        MultipartFile profile = member.getProfile();
        if (profile != null && !profile.isEmpty()) {
            // 새 프로필 파일 저장 및 기존 파일 삭제
            String newProfileName = UUID.randomUUID().toString() + "_" + profile.getOriginalFilename();
            member.setProfileName(newProfileName);

            String savePath = path + "\\" + newProfileName;
            try {
                profile.transferTo(new File(savePath));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            // 기존 파일 삭제
            if (!existingEntity.getProfileName().equals("default.jpg")) {
                new File(path + "\\" + existingEntity.getProfileName()).delete();
            }
        } else {
            // 프로필 변경이 없으면 기존 프로필 유지
            member.setProfileName(existingEntity.getProfileName());
        }

        // (4) 엔티티 업데이트
        existingEntity.setName(member.getName());
        existingEntity.setEmail(member.getEmail());
        existingEntity.setAddress(member.getAddress());
        existingEntity.setProfileName(member.getProfileName());
        existingEntity.setPassword(pwEnc.encode(member.getPassword())); // 비밀번호 암호화

        // (5) 저장
        try {
            mrepo.save(existingEntity);
            mav.setViewName("redirect:/view/" + member.getMemberId());
        } catch (Exception e) {
            mav.setViewName("redirect:/list");
            throw new RuntimeException(e);
        }

        return mav;
    }


    public ModelAndView delete(MemberDTO member) {
        System.out.println("[2] controller → service : " + member);
        mav = new ModelAndView();

        // 기존 프로필 사진이 존재하거나 프로필 이름이 "default.jpg"가 아니라면
        if (member.getProfileName() != null && !member.getProfileName().equals("default.jpg")) {
            String delPath = path + "\\" + member.getProfileName();

            File delFile = new File(delPath);

            if (delFile.exists()) {
                delFile.delete();
            }
        }

        mrepo.deleteById(member.getMemberId());
        session.invalidate();

        mav.setViewName("redirect:/list");

        return mav;
    }

    public List<MemberDTO> getAllUsers() {
        return mrepo.findAll()
                .stream()
                .map(MemberDTO::toDTO)
                .collect(Collectors.toList());
    }


    public ModelAndView login(MemberDTO member, RedirectAttributes redirectAttributes) {
        System.out.println("[2] controller → service : " + member);
        mav = new ModelAndView();

        // (1) 아이디가 존재하는지 확인
        Optional<MemberEntity> entity = mrepo.findById(member.getMemberId());
        if (entity.isPresent()) {
            MemberEntity user = entity.get();

            // (2) 계정 정지 여부 확인
            if ("Y".equals(user.getIsBlocked())) {
                System.out.println("정지된 계정입니다.");
                redirectAttributes.addFlashAttribute("message", "정지된 상태입니다. 관리자에게 문의하세요.");
                mav.setViewName("redirect:/index");
                return mav;
            }

            // (3) 암호화된 비밀번호 일치 확인
            if (pwEnc.matches(member.getPassword(), user.getPassword())) {
                // entity → dto
                MemberDTO login = MemberDTO.toDTO(user);

                session.setAttribute("loginId", login.getMemberId());
                session.setAttribute("loginProfile", login.getProfileName());

                mav.setViewName("redirect:/index"); // 로그인 성공 시 메인 페이지로 리다이렉트
            } else {
                System.out.println("비밀번호가 일치하지 않습니다.");
                redirectAttributes.addFlashAttribute("message", "비밀번호가 일치하지 않습니다.");
                mav.setViewName("redirect:/loginForm");
            }
        } else {
            System.out.println("아이디가 존재하지 않습니다.");
            redirectAttributes.addFlashAttribute("message", "아이디가 존재하지 않습니다.");
            mav.setViewName("redirect:/loginForm");
        }

        return mav;
    }

}
