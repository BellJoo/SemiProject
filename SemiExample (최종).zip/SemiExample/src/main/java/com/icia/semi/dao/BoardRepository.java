package com.icia.semi.dao;

import com.icia.semi.dto.BoardEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface BoardRepository extends JpaRepository<BoardEntity, Integer> {


    // 조회수 증가 메서드
    @Modifying
    @Transactional
    @Query("UPDATE BoardEntity b SET b.views = b.views + 1 WHERE b.boardId = :boardId")
    void incrementViews(@Param("boardId") int boardId);


    // 좋아요 수 증가 메서드
    @Modifying
    @Transactional
    @Query("UPDATE BoardEntity b SET b.likes = b.likes + 1 WHERE b.boardId = :boardId")
    void incrementLikeCount(@Param("boardId") int boardId);


    @Query("SELECT b FROM BoardEntity b WHERE b.boardId = :boardId")
    Optional<BoardEntity> findByBoardId(int boardId);

    // 게시글 리스트 조회
    List<BoardEntity> findAllByOrderByBoardIdDesc();

    // 카테고리와 작성자로 검색
    List<BoardEntity> findByCategoryAndMember_MemberIdContainingOrderByBoardIdDesc(String category, String memberId);

    // 카테고리와 제목으로 검색
    List<BoardEntity> findByCategoryAndTitleContainingOrderByBoardIdDesc(String category, String title);

    // 카테고리와 내용으로 검색
    List<BoardEntity> findByCategoryAndContentContainingOrderByBoardIdDesc(String category, String content);

    // 작성자로만 검색
    List<BoardEntity> findByMember_MemberIdContainingOrderByBoardIdDesc(String memberId);

    // 제목으로만 검색
    List<BoardEntity> findByTitleContainingOrderByBoardIdDesc(String title);

    // 내용으로만 검색
    List<BoardEntity> findByContentContainingOrderByBoardIdDesc(String content);

    List<BoardEntity> findByCategory(String question);
}



