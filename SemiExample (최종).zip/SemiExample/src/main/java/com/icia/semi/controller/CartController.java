//package com.icia.semi.controller;
//
//import com.icia.semi.dto.CartEntity;
//import com.icia.semi.dto.CartItemDTO;
//import com.icia.semi.dto.ProductDTO;
//import com.icia.semi.service.CartService;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/cart")
//public class CartController {
//
//    private final CartService cartService;
//
//    public CartController(CartService cartService) {
//        this.cartService = cartService;
//    }
//
//    @PostMapping("/add")
//    public ResponseEntity<String> addToCart(@RequestParam String memberId, @RequestBody ProductDTO product) {
//        try {
//            cartService.addToCart(memberId, product);
//            return ResponseEntity.ok("장바구니에 상품이 추가되었습니다.");
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("장바구니 추가 실패: " + e.getMessage());
//        }
//    }
//    // 장바구니 목록 가져오기
////    @GetMapping
////    public ResponseEntity<List<CartEntity>> getCartItems(@RequestParam String memberId) {
////        try {
////            List<CartEntity> cartItems = cartService.getCartItems(memberId);
////            return ResponseEntity.ok(cartItems);
////        } catch (Exception e) {
////            return ResponseEntity.badRequest().build();
////        }
////    }
//
//    // 장바구니 목록 가져오기
//    @GetMapping
//    public ResponseEntity<List<CartItemDTO>> getCartItems(@RequestParam String memberId) {
//        try {
//            List<CartItemDTO> cartItems = cartService.getCartItems(memberId);
//            return ResponseEntity.ok(cartItems);
//        } catch (Exception e) {
//            return ResponseEntity.badRequest().build();
//        }
//    }
//
//
//}


package com.icia.semi.controller;

import com.icia.semi.dto.CartItemDTO;
import com.icia.semi.dto.ProductDTO;
import com.icia.semi.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    // 장바구니에 상품 추가
    @PostMapping("/add")
    public ResponseEntity<?> addToCart(@RequestParam String memberId, @RequestBody ProductDTO product) {
        // Validate input parameters
        if (memberId == null || memberId.trim().isEmpty()) {
            logger.warn("memberId is null or empty");
            return ResponseEntity.badRequest().body("회원 ID는 필수입니다.");
        }
        if (product == null || product.getProductId() == null || product.getQuantity() <= 0) {
            logger.warn("Invalid product details");
            return ResponseEntity.badRequest().body("유효하지 않은 상품 정보입니다.");
        }

        try {
            boolean isAdded = cartService.addToCart(memberId, product);
            if (isAdded) {
                logger.info("Product added to cart successfully for memberId: {}", memberId);
                return ResponseEntity.ok("장바구니에 상품이 추가되었습니다.");
            } else {
                logger.error("Failed to add product to cart for memberId: {}", memberId);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("장바구니 추가 실패");
            }
        } catch (Exception e) {
            logger.error("Exception while adding product to cart: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("장바구니 추가 중 오류가 발생했습니다.");
        }
    }

    // 장바구니 목록 가져오기
    @GetMapping
    public ResponseEntity<?> getCartItems(@RequestParam String memberId) {
        // Validate input parameters
        if (memberId == null || memberId.trim().isEmpty()) {
            logger.warn("memberId is null or empty");
            return ResponseEntity.badRequest().body("회원 ID는 필수입니다.");
        }

        try {
            List<CartItemDTO> cartItems = cartService.getCartItems(memberId);
            if (cartItems.isEmpty()) {
                logger.info("No items found in the cart for memberId: {}", memberId);
                return ResponseEntity.ok("장바구니가 비어 있습니다.");
            }
            logger.info("Fetched {} items from cart for memberId: {}", cartItems.size(), memberId);
            return ResponseEntity.ok(cartItems);
        } catch (Exception e) {
            logger.error("Exception while fetching cart items: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("장바구니 항목을 가져오는 중 오류가 발생했습니다.");
        }
    }

    // 장바구니 수량
    @PostMapping("/updateQuantity")
    public ResponseEntity<?> updateCartQuantity(@RequestBody CartItemDTO cartItem) {
        boolean success = cartService.updateQuantity(cartItem.getProductId(), cartItem.getQuantity());
        if (success) {
            return ResponseEntity.ok("수량 업데이트 성공");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("수량 업데이트 실패");
        }
    }

    // 장바구니 물품삭제
    @PostMapping("/deleteSelected")
    public ResponseEntity<Map<String, Object>> deleteSelectedItems(@RequestBody Map<String, Object> payload) {
        String memberId = (String) payload.get("memberId");
        List<String> productIds = (List<String>) payload.get("productIds");

        boolean success = cartService.deleteSelectedItems(memberId, productIds);

        Map<String, Object> response = new HashMap<>();
        response.put("success", success);
        return ResponseEntity.ok(response);
    }


    // 선택된항목만 결제
    @PostMapping("/checkout")
    public ResponseEntity<?> checkout(@RequestBody List<CartItemDTO> selectedItems) {
        boolean success = cartService.checkout(selectedItems);
        if (success) {
            return ResponseEntity.ok("결제 성공");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("결제 실패");
        }
    }

}
