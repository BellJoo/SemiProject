package com.icia.semi.dao;

import com.icia.semi.dto.AdminDTO;
import com.icia.semi.dto.AdminEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface AdminRepository extends JpaRepository<AdminEntity, String> {


    Optional<AdminEntity> findByIsSuperAdmin(String isSuperAdmin);
}
