package com.icia.semi.dto;

import lombok.Data;

@Data
public class SearchDTO {

    private String category;
    private String keyword;
    private String searchType = "title"; // 기본값 설정

}
