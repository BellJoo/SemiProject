package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "inquiries" )
public class InquiryEntity {

    @Id
    private String inquiryId;

    @Column
    private String title;

    @Column
    private String message;

    @Column
    private String adminReply;

    @Column
    private String response;

    @Column
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "memberId")
    private MemberEntity member;

    @ManyToOne
    @JoinColumn(name = "adminId")
    private AdminEntity admin;

    public static InquiryEntity toEntity(InquiryDTO dto){
        InquiryEntity entity = new InquiryEntity();

        entity.setInquiryId(dto.getInquiryId());
        entity.setTitle(dto.getTitle());
        entity.setMessage(dto.getMessage());
        entity.setAdminReply(dto.getAdminReply());
        entity.setResponse(dto.getResponse());
        entity.setCreatedAt(dto.getCreatedAt());

        MemberEntity member = new MemberEntity();
        member.setMemberId(dto.getMemberId());
        entity.setMember(member);

        AdminEntity admin = new AdminEntity();
        admin.setAdminId(dto.getAdminId());
        entity.setAdmin(admin);

        return entity;
    }
}
