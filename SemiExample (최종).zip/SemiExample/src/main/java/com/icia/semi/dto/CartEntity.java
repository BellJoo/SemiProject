package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "cart")
@Data
public class CartEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 기본 키

    @ManyToOne
    @JoinColumn(name = "memberid", nullable = false)
    private MemberEntity member; // 회원과의 관계

    @ManyToOne
    @JoinColumn(name = "productid", nullable = false)
    private ProductEntity product; // 상품과의 관계

    @Column(name = "quantity", nullable = false)
    private int quantity; // 장바구니 수량
}
