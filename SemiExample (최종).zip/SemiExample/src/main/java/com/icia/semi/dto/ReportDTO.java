package com.icia.semi.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
public class ReportDTO {
    private Long reportId;
    private Long reportedEntityId;
    private String reportMemberId;
    private String reportType;
    private String reportReason;
    private String reportStatus;
    private LocalDateTime reportCreatedAt;

    // ReportEntity를 ReportDTO로 변환하는 메서드
    public static ReportDTO toDTO(ReportEntity entity) {
        ReportDTO dto = new ReportDTO();
        dto.setReportId(entity.getReportId());
        dto.setReportedEntityId(entity.getReportedEntityId());
        dto.setReportMemberId(entity.getReportMemberId());
        dto.setReportType(entity.getReportType());
        dto.setReportReason(entity.getReportReason());
        dto.setReportStatus(entity.getReportStatus());
        dto.setReportCreatedAt(entity.getReportCreatedAt());
        return dto;
    }
    // ReportEntity에서 ReportDTO로 변환하는 메서드
    public static ReportDTO fromEntity(ReportEntity entity) {
        ReportDTO dto = new ReportDTO();
        dto.setReportId(entity.getReportId());
        dto.setReportMemberId(entity.getReportMemberId());
        dto.setReportReason(entity.getReportReason());
        dto.setReportStatus(entity.getReportStatus());
        dto.setReportType(entity.getReportType());
        dto.setReportedEntityId(entity.getReportedEntityId());
        dto.setReportCreatedAt(entity.getReportCreatedAt());
        return dto;
    }


    // 포맷된 신고 날짜를 반환하는 메서드 추가
    public String getFormattedReportCreatedAt() {
        return reportCreatedAt != null ? reportCreatedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "";
    }
}
