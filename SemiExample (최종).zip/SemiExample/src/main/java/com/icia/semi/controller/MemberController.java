package com.icia.semi.controller;

import com.icia.semi.dto.MemberDTO;
import com.icia.semi.dto.ReportDTO;
import com.icia.semi.service.MemberService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class MemberController {

    // 서비스클래스 연결
    private final MemberService msvc;

    // Spring 세션 관리
    private final HttpSession session;

    // joinForm : 회원가입 페이지로 이동
    @GetMapping("/joinForm")
    public String joinForm() {
        return "member/join";
    }
    // mLoginForm : 로그인 페이지로 이동
    @GetMapping("/loginForm")
    public String mLoginForm() {
        return "member/login";
    }

    // Join : 회원가입
    @PostMapping("/join")
    public ModelAndView join(@ModelAttribute MemberDTO member) {
        System.out.println("\n회원가입 메소드\n[1] html → controller : " + member);
        return msvc.join(member);
    }

    // mLogin : 로그인
    @PostMapping("/login")
    public ModelAndView login(@ModelAttribute MemberDTO member, RedirectAttributes redirectAttributes) {
        System.out.println("\n로그인 메소드\n[1] html → controller : " + member);
        return msvc.login(member, redirectAttributes);
    }

    @GetMapping("/joinIndex")
    public String joinIndex() {
        return "/joinIndex";
    }

    @GetMapping("loginIndex")
    public String loginIndex() {
        return "/loginIndex";
    }


    // logout : 로그아웃
    @GetMapping("/logout")
    public String logout() {
        session.invalidate();
        return "redirect:/index";
    }

    // View : 회원 상세보기
    @GetMapping("/view/{memberId}")
    public ModelAndView view(@PathVariable String memberId) {
        System.out.println("\n회원상세보기 메소드\n[1] html → controller : " + memberId);
        return msvc.view(memberId);
    }

    // modify : 회원 수정
    @PostMapping("/mModify")
    public ModelAndView mModify(@ModelAttribute MemberDTO member) {
        System.out.println("\n회원수정 메소드\n[1] html → controller : " + member);
        return msvc.mModify(member);
    }

    // Delete : 회원삭제
    @GetMapping("/delete")
    public ModelAndView delete(@ModelAttribute MemberDTO member) {
        System.out.println("\n회원삭제 메소드\n[1] html → controller");
        return msvc.delete(member);
    }

}
