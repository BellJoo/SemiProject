package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "likes")
@SequenceGenerator(name = "L_SEQ_GENERATOR", sequenceName = "L_SEQ", allocationSize = 1)
public class LikeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "L_SEQ_GENERATOR")
    @SequenceGenerator(name = "L_SEQ_GENERATOR", sequenceName = "L_SEQ", allocationSize = 1)
    private int likeId;

    @Column
    private int boardId;

    @Column
    private String loginId;

    public static LikeEntity toEntity(LikeDTO dto){
        LikeEntity entity = new LikeEntity();


        entity.setLikeId(dto.getLikeId());  // likeId 설정 추가
        entity.setBoardId(dto.getBoardId());
        entity.setLoginId(dto.getLoginId());

        return entity;
    }
}
