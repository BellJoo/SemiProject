//package com.icia.semi.service;
//
//import com.icia.semi.dao.AdminRepository;
//import com.icia.semi.dao.BoardRepository;
//import com.icia.semi.dao.MemberRepository;
//import com.icia.semi.dao.ReportRepository;
//import com.icia.semi.dto.*;
//import jakarta.annotation.PostConstruct;
//import jakarta.mail.Message;
//import jakarta.mail.MessagingException;
//import jakarta.mail.internet.InternetAddress;
//import jakarta.mail.internet.MimeMessage;
//import jakarta.servlet.http.HttpSession;
//import lombok.RequiredArgsConstructor;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.servlet.ModelAndView;
//
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Paths;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import java.util.UUID;
//import java.util.stream.Collectors;
//
//@Service
//@RequiredArgsConstructor
//public class AdminService {
//    private final AdminRepository arepo;
//    private final MemberRepository mrepo;
//    private final ReportRepository rrepo;
//    private final BoardRepository brepo;
//
//    private final BCryptPasswordEncoder pwEnc = new BCryptPasswordEncoder();
//    private final JavaMailSender mailSender;
//    private final HttpSession session;
//    private ModelAndView mav;
//
//    public ModelAndView adminJoin(AdminDTO admin) {
//        ModelAndView mav = new ModelAndView();
//        try {
//            // 최고 관리자 존재 여부 확인
//            Optional<AdminEntity> superAdminEntity = arepo.findByIsSuperAdmin("Y");
//
//            if (superAdminEntity.isPresent()) {
//                // 최고 관리자가 있으면, 일반 관리자 처리
//                admin.setIsSuperAdmin("N");
//            } else {
//                // 최고 관리자가 없으면, 최고 관리자 처리
//                admin.setIsSuperAdmin("Y");
//                admin.setManageInquiries("Y");
//                admin.setManageNotices("Y");
//                admin.setManageEvents("Y");
//                admin.setManageReports("Y");
//            }
//
//            // 프로필 이미지 처리
//            MultipartFile adminProfile = admin.getAdminProfile();
//            if (!adminProfile.isEmpty()) {
//                String uuid = UUID.randomUUID().toString().substring(0, 8);
//                String fileName = adminProfile.getOriginalFilename();
//                String adminProfileName = uuid + "_" + fileName;
//
//                admin.setAdminProfileName(adminProfileName);
//
//                // 파일 저장 경로
//                String savePath = Paths.get(System.getProperty("user.dir"), "src/main/resources/static/profile", adminProfileName).toString();
//                File saveFile = new File(savePath);
//                saveFile.getParentFile().mkdirs();  // 디렉토리 생성
//                adminProfile.transferTo(saveFile);  // 파일 저장
//            } else {
//                admin.setAdminProfileName("default.jpg");  // 기본 이미지 사용
//            }
//
//            // 비밀번호 암호화
//            admin.setAdminPw(pwEnc.encode(admin.getAdminPw()));  // BCryptPasswordEncoder 사용
//
//            // DTO -> Entity 변환
//            AdminEntity adminEntity = AdminEntity.toEntity(admin);
//
//            // DB에 저장
//            arepo.save(adminEntity);
//
//            // 회원가입 후 로그인 페이지로 리다이렉트
//            mav.setViewName("admin/adminLogin");
//            mav.addObject("message", "회원가입이 완료되었습니다. 로그인 해주세요.");
//        } catch (IOException e) {
//            mav.setViewName("admin/adminJoin");
//            mav.addObject("error", "파일 업로드 중 오류가 발생했습니다. 다시 시도해주세요.");
//            e.printStackTrace();
//        } catch (Exception e) {
//            mav.setViewName("admin/adminJoin");
//            mav.addObject("error", "회원가입 중 오류가 발생했습니다. 관리자에게 문의해주세요.");
//            e.printStackTrace();
//        }
//
//        return mav;
//    }
//
//    // 최고 관리자가 있는지 확인
//    public boolean isSuperAdminExists() {
//        Optional<AdminEntity> superAdminEntity = arepo.findByIsSuperAdmin("Y");
//        return superAdminEntity.isPresent(); // 최고 관리자가 있으면 true, 없으면 false
//    }
//
//    // 관리자 로그인
//    public ModelAndView adminLogin(AdminDTO admin) {
//        mav = new ModelAndView();
//        try {
//            if (admin.getAdminId() == null || admin.getAdminPw() == null) {
//                mav.setViewName("admin/adminLogin");
//                mav.addObject("error", "아이디와 비밀번호를 모두 입력해주세요.");
//                return mav;
//            }
//
//            Optional<AdminEntity> entity = arepo.findById(admin.getAdminId());
//            if (entity.isPresent()) {
//                if (pwEnc.matches(admin.getAdminPw(), entity.get().getAdminPw())) {
//                    AdminDTO login = AdminDTO.toDTO(entity.get());
//
//                    // 로그인 성공 시 세션에 관리자 정보 저장
//                    saveAdminSession(login);  // 세션 설정을 서비스 메서드에서 처리
//
//                    mav.setViewName("admin/Admin");  // 로그인 후 대시보드 페이지로 리다이렉트
//                } else {
//                    mav.setViewName("admin/adminLogin");
//                    mav.addObject("error", "비밀번호가 일치하지 않습니다.");
//                }
//            } else {
//                mav.setViewName("admin/adminLogin");
//                mav.addObject("error", "아이디가 존재하지 않습니다.");
//            }
//        } catch (Exception e) {
//            mav.setViewName("admin/adminLogin");
//            mav.addObject("error", "로그인 중 오류가 발생했습니다.");
//            e.printStackTrace();
//        }
//
//        return mav;
//    }
//
//    private void saveAdminSession(AdminDTO login) {
//        session.setAttribute("loginId", login.getAdminId());
//        session.setAttribute("loginProfile", login.getAdminProfileName());
//        session.setAttribute("loginName", login.getAdminName());
//        session.setAttribute("isSuperAdmin", login.getIsSuperAdmin());  // String 값 그대로 저장
//        session.setAttribute("adminInquiries", login.getManageInquiries());  // String 값으로 저장
//        session.setAttribute("adminNotices", login.getManageNotices());    // String 값으로 저장
//        session.setAttribute("adminEvents", login.getManageEvents());      // String 값으로 저장
//        session.setAttribute("adminReports", login.getManageReports());    // String 값으로 저장
//    }
//
//
//    // 모든 관리자 정보 가져오기
//    public List<AdminDTO> getAllAdmins() {
//        List<AdminEntity> adminEntities = arepo.findAll();
//
//        // AdminEntity를 AdminDTO로 변환하여 반환
//        return adminEntities.stream()
//                .map(AdminDTO::toDTO)
//                .collect(Collectors.toList());
//    }
//
//    // 관리자의 권한 상태를 반환
//    public Map<String, String> getAdminPermissions(String adminId) {
//        Optional<AdminEntity> adminEntityOpt = arepo.findById(adminId);
//        if (adminEntityOpt.isPresent()) {
//            AdminEntity adminEntity = adminEntityOpt.get();
//            return Map.of(
//                    "adminInquiries", adminEntity.getManageInquiries(),
//                    "adminNotices", adminEntity.getManageNotices(),
//                    "adminEvents", adminEntity.getManageEvents(),
//                    "adminReports", adminEntity.getManageReports()
//            );
//        }
//        return Map.of();  // 빈 맵 반환
//    }
//
//    public String grantPermissions(String adminId, String manageInquiries, String manageNotices,
//                                   String manageEvents, String manageReports) {
//        try {
//            // adminId를 사용하여 관리자 찾기
//            Optional<AdminEntity> adminEntityOpt = arepo.findById(adminId);
//
//            if (adminEntityOpt.isPresent()) {
//                AdminEntity adminEntity = adminEntityOpt.get();
//
//                // 권한 업데이트
//                adminEntity.setManageInquiries(manageInquiries);
//                adminEntity.setManageNotices(manageNotices);
//                adminEntity.setManageEvents(manageEvents);
//                adminEntity.setManageReports(manageReports);
//
//                // DB에 업데이트된 관리자 저장
//                arepo.save(adminEntity);
//                return "권한 부여 성공";
//            } else {
//                // 관리자가 존재하지 않는 경우
//                return "관리자가 존재하지 않습니다.";
//            }
//        } catch (Exception e) {
//            // 예외 발생 시 로그를 추가하는 것이 좋습니다
//            // 예시: logger.error("권한 부여 실패", e);
//            return "권한 부여 실패: " + e.getMessage();
//        }
//    }
//    // 아이디 중복 체크
//    public String adminidCheck(String adminId) {
//        try {
//            // 아이디로 관리자가 존재하는지 확인
//            Optional<AdminEntity> entity = arepo.findById(adminId);
//            if (entity.isPresent()) {
//                return "NO"; // 아이디가 이미 존재
//            } else {
//                return "OK"; // 아이디 사용 가능
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "ERROR"; // 예외 발생 시
//        }
//    }
//
//    // 이메일 인증번호 발송
//    public String adminemailCheck(String adminEmail) {
//        String uuid = UUID.randomUUID().toString().substring(0, 8);  // 8자리 인증번호 생성
//
//        // 이메일 발송 내용
//        MimeMessage mail = mailSender.createMimeMessage();
//        String message = "<h2>안녕하세요. 관리자를 위한 이메일 인증번호</h2>"
//                + "<p>인증번호는 <b>" + uuid + "</b> 입니다.</p>";
//
//        try {
//            mail.setSubject("관리자 이메일 인증번호");
//            mail.setText(message, "UTF-8", "html");
//            mail.addRecipient(Message.RecipientType.TO, new InternetAddress(adminEmail));
//
//            //mailSender.send(mail);  // 이메일 전송
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            throw new RuntimeException("이메일 전송 오류");
//        }
//
//        return uuid; // 인증번호 반환
//    }
//    // 슈퍼 관리자의 권한을 자동으로 'Y'로 설정하는 메서드
//    public void updateSuperAdminPermissions() {
//        // 'Y'인 슈퍼 관리자 찾기
//        Optional<AdminEntity> superAdminEntity = arepo.findByIsSuperAdmin("Y");
//
//        // 슈퍼 관리자가 있으면 권한을 업데이트
//        if (superAdminEntity.isPresent()) {
//            AdminEntity superAdmin = superAdminEntity.get();
//
//            // 권한을 모두 'Y'로 설정
//            superAdmin.setManageInquiries("Y");
//            superAdmin.setManageNotices("Y");
//            superAdmin.setManageEvents("Y");
//            superAdmin.setManageReports("Y");
//
//            // 업데이트된 엔티티를 DB에 저장
//            arepo.save(superAdmin);
//        }
//    }
//
//    @PostConstruct
//    public void init() {
//        updateSuperAdminPermissions();
//    }
//
//
//    // 관리자 상세 정보 조회
//    @GetMapping("/admins/api")
//    public AdminDTO getAdminDetails(String adminId) {
//        // 관리자 엔티티를 조회
//        Optional<AdminEntity> admin = arepo.findById(adminId);
//        return admin.map(AdminDTO::fromEntity).orElse(null); // 필요 타입이 AdminDTO이므로 반환값이 맞도록 처리
//
//       /*   Optional<AdminEntity> adminEntityOpt = arepo.findById(adminId);
//
//      // 관리자 정보가 있으면 DTO로 변환하여 반환
//        if (adminEntityOpt.isPresent()) {
//            AdminEntity adminEntity = adminEntityOpt.get();
//            return AdminDTO.toDTO(adminEntity);  // AdminEntity를 AdminDTO로 변환하여 반환
//        }
//
//        // 관리자 정보가 없으면 null 반환
//        return null;*/
//    }
//
//    /*---------결함본----------*/
//    // 모든 회원 목록 조회
//    public List<MemberDTO> getAllMembers() {
//        List<MemberEntity> entities = mrepo.findAll(); // 모든 회원 엔티티 조회
//        return entities.stream()
//                .map(MemberDTO::fromEntity) // 엔티티를 DTO로 변환
//                .collect(Collectors.toList());
//    }
//
//    // 신고 목록 조회
//    public List<ReportDTO> getAllReports() {
//        List<ReportEntity> reportEntities = rrepo.findAll();
//        return reportEntities.stream()
//                .map(ReportDTO::fromEntity)
//                .collect(Collectors.toList());
//    }
//
//    // 권한 파트 시도 중
//    // 회원 정지 메서드
//    // 회원 정지 메서드
//    public boolean blockUser(String memberId) {
//        try {
//            Optional<MemberEntity> memberOptional = mrepo.findById(memberId);
//            if (memberOptional.isPresent()) {
//                MemberEntity member = memberOptional.get();
//                member.setIsBlocked("Y"); // 정지 상태로 설정
//                mrepo.save(member); // 변경사항 저장
//                return true; // 성공적으로 저장한 경우
//            } else {
//                System.out.println("회원이 존재하지 않습니다.");
//                return false; // memberId에 해당하는 회원이 없는 경우
//            }
//        } catch (Exception e) {
//            System.err.println("회원 정지 처리 중 오류 발생: " + e.getMessage());
//            e.printStackTrace();
//            return false;
//        }
//    }
//
//
//    // 신고 완료 처리 메서드
//    public boolean markReportAsCompleted(Long reportId) {
//        Optional<ReportEntity> reportOptional = rrepo.findById(reportId);
//        if (reportOptional.isPresent()) {
//            ReportEntity report = reportOptional.get();
//            report.setReportStatus("완료"); // 상태를 '완료'로 설정
//            rrepo.save(report);            // 변경사항 저장
//            return true;                   // 성공적으로 저장한 경우
//        }
//        return false; // reportId에 해당하는 신고가 없는 경우
//    }
//
//
//    public boolean toggleUserBlockStatus(String memberId) {
//        Optional<MemberEntity> memberOptional = mrepo.findById(memberId);
//        if (memberOptional.isPresent()) {
//            MemberEntity member = memberOptional.get();
//            // 현재 상태를 확인하고 토글
//            String newStatus = "Y".equals(member.getIsBlocked()) ? "N" : "Y";
//            member.setIsBlocked(newStatus); // 상태 변경
//            mrepo.save(member); // 변경사항 저장
//            return true;
//        }
//        return false; // memberId에 해당하는 회원이 없는 경우
//    }
//
//    public List<BoardDTO> getInquiries() {
//        List<BoardEntity> inquiryEntities = brepo.findByCategory("question");
//        return inquiryEntities.stream().map(BoardDTO::toDTO).collect(Collectors.toList());
//    }
//
//}


package com.icia.semi.service;

import com.icia.semi.dao.BoardRepository;
import com.icia.semi.dao.MemberRepository;
import com.icia.semi.dao.ReportRepository;
import com.icia.semi.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final MemberRepository mrepo;
    private final ReportRepository rrepo;
    private final BoardRepository brepo;
    private ModelAndView mav;


    // 모든 회원 목록 조회
    public List<MemberDTO> getAllMembers() {
        List<MemberEntity> entities = mrepo.findAll(); // 모든 회원 엔티티 조회
        return entities.stream()
                .map(MemberDTO::fromEntity) // 엔티티를 DTO로 변환
                .collect(Collectors.toList());
    }

    // 신고 목록 조회
    public List<ReportDTO> getAllReports() {
        List<ReportEntity> reportEntities = rrepo.findAll();
        return reportEntities.stream()
                .map(ReportDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // 권한 파트 시도 중
    // 회원 정지 메서드
    // 회원 정지 메서드
    public boolean blockUser(String memberId) {
        try {
            Optional<MemberEntity> memberOptional = mrepo.findById(memberId);
            if (memberOptional.isPresent()) {
                MemberEntity member = memberOptional.get();
                member.setIsBlocked("Y"); // 정지 상태로 설정
                mrepo.save(member); // 변경사항 저장
                return true; // 성공적으로 저장한 경우
            } else {
                System.out.println("회원이 존재하지 않습니다.");
                return false; // memberId에 해당하는 회원이 없는 경우
            }
        } catch (Exception e) {
            System.err.println("회원 정지 처리 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    // 신고 완료 처리 메서드
    public boolean markReportAsCompleted(Long reportId) {
        Optional<ReportEntity> reportOptional = rrepo.findById(reportId);
        if (reportOptional.isPresent()) {
            ReportEntity report = reportOptional.get();
            report.setReportStatus("완료"); // 상태를 '완료'로 설정
            rrepo.save(report);            // 변경사항 저장
            return true;                   // 성공적으로 저장한 경우
        }
        return false; // reportId에 해당하는 신고가 없는 경우
    }


    public boolean toggleUserBlockStatus(String memberId) {
        Optional<MemberEntity> memberOptional = mrepo.findById(memberId);
        if (memberOptional.isPresent()) {
            MemberEntity member = memberOptional.get();
            // 현재 상태를 확인하고 토글
            String newStatus = "Y".equals(member.getIsBlocked()) ? "N" : "Y";
            member.setIsBlocked(newStatus); // 상태 변경
            mrepo.save(member); // 변경사항 저장
            return true;
        }
        return false; // memberId에 해당하는 회원이 없는 경우
    }

    public List<BoardDTO> getInquiries() {
        List<BoardEntity> inquiryEntities = brepo.findByCategory("question");
        return inquiryEntities.stream().map(BoardDTO::toDTO).collect(Collectors.toList());
    }
}
