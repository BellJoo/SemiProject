//package com.icia.semi.dao;
//
//import com.icia.semi.dto.CartEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//import java.util.Optional;
//
//
//@Repository
//public interface CartRepository extends JpaRepository<CartEntity, String> {
//
////    List<CartEntity> findByMemberMemberId(String memberId);
//
//    // 특정 회원의 장바구니 아이템 목록 조회
////    List<CartEntity> findByMember_MemberId(String memberId);
//
//
//
////    List<CartEntity> findByMemberMemberId(String memberId);
//
////    Optional<CartEntity> findByMemberIdAndProductId(String memberId, String productId);
//
//
//    //    List<CartEntity> findByMemberId(String memberId);
//
//
//
//
//    // 특정 회원의 장바구니 항목 검색
////    List<CartEntity> findByMemberId(String memberId);
//
//    // 특정 회원과 상품으로 장바구니 항목 검색
////    Optional<CartEntity> findByMemberIdAndProductId(String memberId, String productId);
//
//    // memberId와 productId를 기반으로 검색
//    Optional<CartEntity> findByMember_MemberIdAndProduct_ProductId(String memberId, String productId);
//
//
//    // 특정 회원(memberId)의 장바구니 항목 검색
//    List<CartEntity> findByMember_MemberId(String memberId);
//
//
//
//}


package com.icia.semi.dao;

import com.icia.semi.dto.CartEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<CartEntity, Long> {
    List<CartEntity> findByMember_MemberId(String memberId);

    Optional<CartEntity> findByMember_MemberIdAndProduct_ProductId(String memberId, String productId);

    Optional<CartEntity> findByProductProductId(String productid);

    void deleteByMember_MemberIdAndProduct_ProductId(String memberId, String productId);
}
