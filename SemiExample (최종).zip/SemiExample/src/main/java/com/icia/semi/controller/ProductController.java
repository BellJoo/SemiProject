package com.icia.semi.controller;

import com.icia.semi.dao.ProductRepository;
import com.icia.semi.dto.ProductDTO;
import com.icia.semi.dto.ProductEntity;
import com.icia.semi.service.CartService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
public class ProductController {

    private final ProductRepository prepo;
    private final CartService cartService;

    // 생성자에서 ProductRepository와 CartService를 주입받음
    public ProductController(ProductRepository productRepository, CartService cartService) {
        this.prepo = productRepository;
        this.cartService = cartService;
    }

    @GetMapping("/api/recommended-products")
    public Map<String, List<ProductEntity>> getRecommendedProducts() {
        List<ProductEntity> products = prepo.findAll();
        return products.stream().collect(Collectors.groupingBy(ProductEntity::getCategory));
    }

    @PostMapping("/cart/add")
    public ResponseEntity<String> addToCart(@RequestParam String memberId, @RequestBody ProductDTO product) {
        boolean isAdded = cartService.addToCart(memberId, product);
        if (isAdded) {
            return ResponseEntity.ok("장바구니에 상품이 추가되었습니다.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("장바구니 추가 실패!");
        }
    }
}
