package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "members")
public class MemberEntity {

    @Id
    @Column(name = "memberId", length = 36)
    private String memberId;

    @Column(name = "password", nullable = false, length = 255)
    private String password; // 암호화된 비밀번호

    @Column(name = "name", nullable = false, length = 100)
    private String name; // 이름

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "birth")
    private Date birth;  // 생년월일

    @Column
    private String gender;  // 성별

    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email; // 이메일 (고유 값)

    @Column(name = "phone", length = 20)
    private String phone; // 핸드폰 번호

    @Column(name = "address", length = 255)
    private String address; // 주소


    @Column(name = "profile_name", length = 255)
    private String profileName; // 프로필 이미지 파일 이름

    @Column(name = "is_blocked", length = 1, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String isBlocked = "N"; // 차단 여부 ('N', 'Y')

    @Column(name = "block_until")
    private Date blockUntil; // 차단 해제 시각

    // MemberEntity.java (회원이 여러 신고를 할 수 있는 경우)
    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL)
    private List<ReportEntity> reports;

    @OneToMany(mappedBy = "member")
    private List<BoardEntity> board;

    @OneToMany(mappedBy = "member")
    private List<CommentEntity> comment;

    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartEntity> cartItems;


    // DTO에서 엔티티로 변환하는 메소드
    public static MemberEntity toEntity(MemberDTO dto) {

        MemberEntity entity = new MemberEntity();

        entity.setMemberId(dto.getMemberId());
        entity.setPassword(dto.getPassword());
        entity.setName(dto.getName());
        entity.setBirth(dto.getBirth());
        entity.setGender(dto.getGender());
        entity.setEmail(dto.getEmail());
        entity.setPhone(dto.getPhone());
        entity.setAddress(dto.getAddress());
        entity.setProfileName(dto.getProfileName());
        entity.setIsBlocked(dto.getIsBlocked());
        entity.setBlockUntil(dto.getBlockUntil());

        return entity;
    }

}
