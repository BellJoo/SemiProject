package com.icia.semi.controller;

import com.icia.semi.dto.BoardDTO;
import com.icia.semi.dto.SearchDTO;
import com.icia.semi.service.AdminService;
import com.icia.semi.service.BoardService;
import com.icia.semi.service.MemberService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class RestfulController {

    private final MemberService msvc;
    private final BoardService bsvc;
    private final AdminService asvc;



    // 아이디 체크
    @PostMapping("/idCheck")
    public String idCheck(@RequestParam("memberId")String memberId){
        String result = msvc.idCheck(memberId);
        return result;
    }

    // 이메일 체크
    @PostMapping("/emailCheck")
    public String emailCheck(@RequestParam("email") String email){
        return msvc.emailCheck(email);
    }

//    // 아이디 중복 체크
//    @PostMapping("/adminIdCheck")
//    public String adminIdCheck(@RequestParam("adminId") String adminId) {
//        // 아이디 중복 확인 서비스 호출
//        System.out.println("[1] adminId : " + adminId);
//        String result = asvc.adminidCheck(adminId);
//        System.out.println("[5] result : " + result);
//        return result;  // 중복 확인 결과 반환 (OK/NO/ERROR)
//    }
//
//    // 이메일 인증번호 발송
//    @PostMapping("/adminEmailCheck")
//    public String adminEmailCheck(@RequestParam("adminEmail") String adminEmail) {
//        // 이메일 인증번호 발송 서비스 호출
//        System.out.println("[1] adminEmail : " + adminEmail);
//        String uuid = asvc.adminemailCheck(adminEmail);
//        System.out.println("[5] result : " + uuid); // 이메일 인증번호 출력
//        return uuid;  // 인증번호 반환
//    }


    // boardList
    @PostMapping("/boardList")
    public List<BoardDTO> boardList(){
        return bsvc.boardList();
    }

    // searchList
    @PostMapping("/searchList")
    public List<BoardDTO> searchList(@ModelAttribute SearchDTO search){
        return bsvc.searchList(search);
    }


    // like
    @PostMapping("/like")
    public ResponseEntity<Map<String, Object>> likePost(@RequestParam int boardId, HttpSession session) {
        String loginId = (String) session.getAttribute("loginId");
        Map<String, Object> response = new HashMap<>();

        if (loginId == null) {
            response.put("success", false);
            response.put("message", "로그인 후 좋아요를 누를 수 있습니다.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        boolean liked = bsvc.incrementLike(boardId, loginId);

        if (liked) {
            response.put("success", true);
            response.put("newLikeCount", bsvc.getLikeCount(boardId));
        } else {
            response.put("success", false);
        }

        return ResponseEntity.ok(response);
    }


    // checkAdmin
    @GetMapping("/checkAdmin")
    @ResponseBody
    public Map<String, Object> checkAdmin(HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        String loginId = (String) session.getAttribute("loginId");  // 세션에서 로그인된 사용자 ID 확인

        if ("adminId".equals(loginId)) {  // 관리자 ID 확인
            response.put("isAdmin", true);  // 관리자일 경우
        } else {
            response.put("isAdmin", false);  // 관리자 아니면
        }

        return response;
    }


}
