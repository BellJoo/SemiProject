package com.icia.semi.dto;

import lombok.Data;

@Data
public class ExerciseGuideDTO {
    private String guideId;         // 운동 가이드 ID
    private String gname;           // 운동 이름 (한글명)
    private String gename;          // 운동 이름 (영문명)
    private String gdescription;    // 설명
    private String gvideoUrl;       // 자세 설명 동영상 URL
    private String gbodyPart;       // 운동 부위
    private String gimageLink;      // 운동 기구 이미지 링크
    private String gdetailLink;     // 운동 기구 상세 링크


    public static ExerciseGuideDTO toDTO(ExerciseGuideEntity entity) {
        ExerciseGuideDTO dto = new ExerciseGuideDTO();
        dto.setGuideId(entity.getGuideId());
        dto.setGname(entity.getGname());
        dto.setGename(entity.getGename());
        dto.setGdescription(entity.getGdescription());
        dto.setGvideoUrl(entity.getGvideoUrl());
        dto.setGbodyPart(entity.getGbodyPart());
        dto.setGimageLink(entity.getGimageLink());
        dto.setGdetailLink(entity.getGdetailLink());

        return dto;
    }

    public static ExerciseGuideEntity toEntity(ExerciseGuideDTO dto) {
        ExerciseGuideEntity entity = new ExerciseGuideEntity();
        entity.setGuideId(dto.getGuideId());
        entity.setGname(dto.getGname());
        entity.setGename(dto.getGename());
        entity.setGdescription(dto.getGdescription());
        entity.setGvideoUrl(dto.getGvideoUrl());
        entity.setGbodyPart(dto.getGbodyPart());
        entity.setGimageLink(dto.getGimageLink());
        entity.setGdetailLink(dto.getGdetailLink());

        return entity;
    }
}
