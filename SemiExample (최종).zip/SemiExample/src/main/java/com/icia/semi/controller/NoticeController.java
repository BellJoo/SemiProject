package com.icia.semi.controller;

import com.icia.semi.dto.NoticeDTO;
import com.icia.semi.service.NoticeService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/notice")  // 기본 경로를 notice로 설정
public class NoticeController {

    private final NoticeService nsvc;
    private final HttpSession session;

    @GetMapping("/noticeIndex")
    public String index() {
        return "notice/noticeIndex";  // view 이름이 'index'로 렌더링되도록 처리
    }

    @GetMapping("/noticeWriteForm")
    public String noticeWriteForm(){

        return "notice/noticeWrite";
    }
    //공지사항 작성
    @PostMapping("noticeWrite")
    public ModelAndView noticeWrite(@ModelAttribute NoticeDTO notice) {
        System.out.println("\n게시글작성\n[1] board : " + notice);
        return nsvc.noticeWrite(notice);
    }
    @GetMapping("/notice/noticeList")
    public ModelAndView noticeList() {
        ModelAndView mav = new ModelAndView("notice/noticeList");
        // 공지사항 목록을 가져와서 모델에 추가
        mav.addObject("noticeList", nsvc.getAllNotices());
        return mav;
    }
}


