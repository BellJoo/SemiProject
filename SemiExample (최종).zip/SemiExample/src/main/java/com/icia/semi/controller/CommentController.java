// CommentController.java
package com.icia.semi.controller;

import com.icia.semi.dto.CommentDTO;
import com.icia.semi.service.CommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class CommentController {

    private final CommentService csvc;

    // 댓글 목록 조회
    @PostMapping("/cList")
    public List<CommentDTO> cList(@RequestParam("boardId") int boardId) {
        System.out.println("\n댓글 목록\n[1]html → controller : " + boardId);
        return csvc.cList(boardId);
    }

    // 댓글 작성
//    @PostMapping("/cWrite")
//    public List<CommentDTO> cWrite(@ModelAttribute CommentDTO comment) {
//        System.out.println("\n댓글 작성\n[1]html → controller : " + comment);
//        return csvc.cWrite(comment);
//    }


    @PostMapping("/cWrite")
    public Map<String, Object> cWrite(@RequestBody CommentDTO comment) {
        System.out.println("\n댓글 작성\n[1]html → controller : " + comment);
        Map<String, Object> response = new HashMap<>();

        try {
            csvc.cWrite(comment);
            response.put("success", true);
            response.put("comments", csvc.cList(comment.getBoardId())); // 댓글 목록을 다시 가져와 반환
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
        }
        return response;
    }




//    // 댓글 삭제
//    @PostMapping("/cDelete")
//    public List<CommentDTO> cDelete(@ModelAttribute CommentDTO comment) {
//        System.out.println("\n댓글 삭제\n[1]html → controller : " + comment);
//        return csvc.cDelete(comment);
//    }

    // 댓글 수정
    @PostMapping("/cModify")
    @ResponseBody
    public Map<String, Object> cModify(@RequestBody CommentDTO comment) {
        System.out.println("\n댓글 수정\n[1]html → controller : " + comment);

        Map<String, Object> response = new HashMap<>();
        try {
            csvc.cModify(comment); // 댓글 수정 서비스 호출
            response.put("success", true); // 수정 성공 여부
            response.put("comments", csvc.cList(comment.getBoardId())); // 수정 후 댓글 목록 반환
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false); // 실패 시 success를 false로 설정
        }
        return response; // JSON 형태로 success 상태와 댓글 목록 반환
    }



    @PostMapping("/cDelete")
    @ResponseBody
    public Map<String, Object> cDelete(@RequestBody CommentDTO comment) {
        System.out.println("\n댓글 삭제\n[1]html → controller : " + comment);

        Map<String, Object> response = new HashMap<>();
        try {
            csvc.cDelete(comment); // 댓글 삭제 서비스 호출
            response.put("success", true); // 삭제 성공 여부
            response.put("comments", csvc.cList(comment.getBoardId())); // 삭제 후 댓글 목록 반환
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false); // 실패 시 success를 false로 설정
        }
        return response; // JSON 형태로 success 상태와 댓글 목록 반환
    }
}