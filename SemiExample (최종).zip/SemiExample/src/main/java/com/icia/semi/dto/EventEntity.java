package com.icia.semi.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Data
@Table(name = "EVENTENTITY")
public class EventEntity {
    @Id
    private String Event_Id;        // 이벤트 고유 ID

    @Column
    private String Admin_Id;        // 작성자 ID

    @Column
    private String Event_Title;          // 이벤트 제목

    @Column
    private String Event_Message;        // 이벤트 내용

    @Column
    private LocalDate Event_StartDate;   // 이벤트 시작일

    @Column
    private LocalDate Event_EndDate;     // 이벤트 종료일

    @Column
    private LocalDate Event_CreatedAt;   // 이벤트 생성일

    public static EventEntity toEntity(EventDTO dto){
        EventEntity entity = new EventEntity();

        entity.setEvent_Id(dto.getEvent_Id());
        entity.setAdmin_Id(dto.getAdmin_Id());
        entity.setEvent_Title(dto.getEvent_Title());
        entity.setEvent_Message(dto.getEvent_Message());
        entity.setEvent_StartDate(dto.getEvent_StartDate());
        entity.setEvent_EndDate(dto.getEvent_EndDate());
        entity.setEvent_CreatedAt(dto.getEvent_CreatedAt());

        return entity;
    }
}
