package com.icia.semi.dao;

import com.icia.semi.dto.ExerciseGuideEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExerciseGuideRepository extends JpaRepository<ExerciseGuideEntity, String> {

    // Find guides by body part
    List<ExerciseGuideEntity> findByGbodyPart(String bodyPart);

    // Find a guide by its unique ID
    Optional<ExerciseGuideEntity> findByGuideId(String guideId);
}
