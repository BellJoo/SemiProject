package com.icia.semi.service;

import com.icia.semi.dao.NoticeRepository;
import com.icia.semi.dto.NoticeDTO;
import com.icia.semi.dto.NoticeEntity;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository nrepo;
    ModelAndView mav = new ModelAndView();


    /*  public ModelAndView noticeWrite(NoticeDTO notice) {
          System.out.println("[2]controller > service : " + notice);
         ModelAndView mav = new ModelAndView();

          try{
          NoticeEntity entity = NoticeEntity.toEntity(notice);
          nrepo.save(entity);
          mav.setViewName("redirect:/adminIndex");  // 성공 시 관리자 인덱스로 리다이렉트

          }catch (Exception e){
              System.out.println("공지사항 등록 실패 !");
              mav.addObject("errorMessage", "공지사항 등록에 실패했습니다.");  // 오류 메시지 추가
              mav.setViewName("notice/noticeWrite");  // 실패 시 원래 폼으로 돌아감
          }
          return mav;
      }*/
    @Transactional
    public ModelAndView noticeWrite(NoticeDTO notice) {
        try {
            NoticeEntity entity = NoticeEntity.toEntity(notice);
            nrepo.save(entity);
            mav.setViewName("redirect:/adminIndex");
        } catch (Exception e) {
            System.out.println("공지사항 등록 실패! 오류: " + e.getMessage());
            e.printStackTrace();
            mav.addObject("errorMessage", "공지사항 등록에 실패했습니다.");
            mav.setViewName("notice/noticeWrite");
        }
        return mav;
    }
    @Transactional  // 트랜잭션을 시작하고, 성공적으로 끝나면 자동으로 commit
    public void createNotice(NoticeDTO noticeDTO) {
        // noticeDTO는 데이터가 채워진 객체입니다.
        NoticeEntity noticeEntity = new NoticeEntity();
        noticeEntity.setAdminId(noticeDTO.getAdminId());
        noticeEntity.setNoticeTitle(noticeDTO.getNoticeTitle());
        noticeEntity.setNoticeMessage(noticeDTO.getNoticeMessage());

        // 트리거가 자동으로 notice_id를 할당합니다.
        nrepo.save(noticeEntity);  // 이 시점에서 트리거가 실행됩니다.

        // 트랜잭션이 끝나면 자동으로 commit됩니다.
    }

    // 공지사항 목록 가져오기
    public List<NoticeDTO> getAllNotices() {
        // NoticeEntity 목록을 가져와 NoticeDTO로 변환
        List<NoticeEntity> noticeEntities = nrepo.findAll();
        return noticeEntities.stream()
                .map(NoticeDTO::toDTO)
                .collect(Collectors.toList());
    }
}
