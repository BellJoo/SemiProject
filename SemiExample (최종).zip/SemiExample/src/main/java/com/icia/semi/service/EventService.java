package com.icia.semi.service;

import com.icia.semi.dao.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository erepo;

    ModelAndView mav = new ModelAndView();
}
