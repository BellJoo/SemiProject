package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "report")
@SequenceGenerator(name = "REPORT_SEQ_GENERATOR", sequenceName = "REPORT_SEQ", allocationSize = 1)
public class ReportEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "REPORT_SEQ_GENERATOR")
    private Long reportId;

    @Column(nullable = false)
    private Long reportedEntityId;

    @Column(nullable = false)
    private String reportMemberId;

    @Column(nullable = false)
    private String reportType;

    @Column(nullable = false)
    private String reportReason;

    @Column(nullable = false)
    private String reportStatus = "보류";

    @Column(nullable = false)
    private LocalDateTime reportCreatedAt = LocalDateTime.now();



    // ReportEntity.java
    @ManyToOne
    @JoinColumn(name = "memberId", insertable = false, updatable = false)
    private MemberEntity member;

    // ReportDTO를 ReportEntity로 변환하는 메서드
    public static ReportEntity toEntity(ReportDTO dto) {
        ReportEntity entity = new ReportEntity();
        entity.setReportedEntityId(dto.getReportedEntityId());
        entity.setReportMemberId(dto.getReportMemberId());
//        entity.setReportType(dto.getReportType() != null ? dto.getReportType() : "기본 타입");
//        entity.setReportReason(dto.getReportReason() != null ? dto.getReportReason() : "기본 이유");
//        entity.setReportStatus(dto.getReportStatus() != null ? dto.getReportStatus() : "보류");
//        entity.setReportCreatedAt(dto.getReportCreatedAt() != null ? dto.getReportCreatedAt() : LocalDateTime.now());
        entity.setReportType(dto.getReportType() != null ? dto.getReportType() : "기본 타입");
        entity.setReportReason(dto.getReportReason() != null ? dto.getReportReason() : "기본 이유");
        entity.setReportStatus(dto.getReportStatus() != null ? dto.getReportStatus() : "보류");
        entity.setReportCreatedAt(dto.getReportCreatedAt() != null ? dto.getReportCreatedAt() : LocalDateTime.now());

        return entity;
    }
}
