package com.icia.semi.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CommentDTO {
    private int commentId;
    private int boardId;        // 댓 달린 게시물
    private String memberId;    // 댓 작성자
    private String content;     // 댓 내용
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

//    public static CommentDTO toDTO(CommentEntity entity){
//        CommentDTO dto = new CommentDTO();
//
//        dto.setCommentId(entity.getCommentId());
//        dto.setContent(entity.getContent());
//        dto.setCreatedAt(entity.getCreatedAt());
//        dto.setUpdatedAt(entity.getUpdatedAt());
//
//        dto.setBoardId(entity.getBoard().getBoardId());
//        dto.setMemberId(entity.getMember().getMemberId());
//
//        return dto;
//    }

    public static CommentDTO toDTO(CommentEntity entity) {
        CommentDTO dto = new CommentDTO();

        dto.setCommentId(entity.getCommentId());
        dto.setContent(entity.getContent());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());

        if (entity.getBoard() != null) {
            dto.setBoardId(entity.getBoard().getBoardId());
        }
        if (entity.getMember() != null) {
            dto.setMemberId(entity.getMember().getMemberId());
        }

        return dto;
    }


}
