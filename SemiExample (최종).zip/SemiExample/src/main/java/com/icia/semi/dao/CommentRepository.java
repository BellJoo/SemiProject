package com.icia.semi.dao;

import com.icia.semi.dto.CommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface CommentRepository extends JpaRepository<CommentEntity, Integer> {

    List<CommentEntity> findAllByBoard_BoardId(int boardId);

    List<CommentEntity> findAllByBoard_boardId(int cBoardId);


    int countByBoard_BoardId(int boardId);
}
