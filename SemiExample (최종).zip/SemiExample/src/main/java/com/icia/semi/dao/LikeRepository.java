//package com.icia.semi.dao;
//
//import com.icia.semi.dto.LikeEntity;
//import jakarta.transaction.Transactional;
//import org.hibernate.type.descriptor.converter.spi.JpaAttributeConverter;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//public interface LikeRepository extends JpaRepository<LikeEntity, Integer> {
////    @Query("SELECT COUNT(l) > 0 FROM LikeEntity l WHERE l.boardId = :boardId AND l.loginId = :loginId")
////    boolean hasUserLiked(@Param("boardId")int boardId, @Param("loginId")String loginId);
////
////    void saveLike(int boardId, String loginId);
//
//    //    @Modifying
////    @Transactional
////    @Query("UPDATE BoardEntity b SET b.Likes = b.Likes + 1 WHERE b.boardId = :boardId")
////    void incrementLikeCount(@Param("boardId") int boardId);
//
//// 사용자가 해당 게시글에 좋아요를 눌렀는지 확인
//    @Query("SELECT COUNT(l) > 0 FROM LikeEntity l WHERE l.boardId = :boardId AND l.loginId = :loginId")
//    boolean hasUserLiked(@Param("boardId") int boardId, @Param("loginId") String loginId);
//
//
//    // 좋아요 수 증가
//    @Modifying
//    @Transactional
//    @Query("UPDATE BoardEntity b SET b.likes = b.likes + 1 WHERE b.boardId = :boardId")
//    void incrementLikeCount(@Param("boardId") int boardId);
//}





//package com.icia.semi.dao;
//
//import com.icia.semi.dto.LikeEntity;
//import jakarta.transaction.Transactional;
//import org.hibernate.type.descriptor.converter.spi.JpaAttributeConverter;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//public interface LikeRepository extends JpaRepository<LikeEntity, Integer> {
//
//    // 특정 게시글에 대해 사용자가 좋아요를 눌렀는지 확인
//    @Query("SELECT COUNT(l) > 0 FROM LikeEntity l WHERE l.boardId = :boardId AND l.loginId = :loginId")
//    boolean hasUserLiked(@Param("boardId") int boardId, @Param("loginId") String loginId);
//
//    // 새로운 좋아요 저장
//    @Modifying
//    @Transactional
//    @Query(value = "INSERT INTO Likes (boardId, loginId) VALUES (:boardId, :loginId)", nativeQuery = true)
//    void saveLike(@Param("boardId") int boardId, @Param("loginId") String loginId);
//
//
//    int countByBoardId(int boardId);
//
//}

package com.icia.semi.dao;

import com.icia.semi.dto.LikeEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LikeRepository extends JpaRepository<LikeEntity, Integer> {

    // 특정 게시글에 대해 사용자가 좋아요를 눌렀는지 확인
    @Query("SELECT COUNT(l) > 0 FROM LikeEntity l WHERE l.boardId = :boardId AND l.loginId = :loginId")
    boolean hasUserLiked(@Param("boardId") int boardId, @Param("loginId") String loginId);

    // 새로운 좋아요 저장
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO likes (likeId, boardId, loginId) VALUES (L_SEQ.NEXTVAL, :boardId, :loginId)", nativeQuery = true)
    void saveLike(@Param("boardId") int boardId, @Param("loginId") String loginId);



    // 특정 게시글에 대한 좋아요 수 카운트
    int countByBoardId(int boardId);
}
