package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

@Data
@Entity
@Table(name = "exerciseguides")
public class ExerciseGuideEntity {

    @Id
    @Column(name = "guideid", length = 36)
    private String guideId = UUID.randomUUID().toString(); // UUID로 고유 ID 자동 생성

    @Column(name = "gname", nullable = false, length = 150)
    private String gname;           // 운동 이름 (한글명)

    @Column(name = "gename", length = 150)
    private String gename;          // 운동 이름 (영문명)

    @Column(name = "gdescription", nullable = false, length = 1000)
    private String gdescription;    // 설명

    @Column(name = "gvideourl", length = 255)
    private String gvideoUrl;       // 자세 설명 동영상 URL

    @Column(name = "gbodypart", length = 100)
    private String gbodyPart;       // 운동 부위

    @Column(name = "gimagelink", length = 255)
    private String gimageLink;      // 운동 기구 이미지 링크

    @Column(name = "gdetailLink", length = 255)
    private String gdetailLink;     // 운동 기구 상세 링크

    public static ExerciseGuideEntity toEntity(ExerciseGuideDTO dto) {
        ExerciseGuideEntity entity = new ExerciseGuideEntity();
        entity.setGuideId(dto.getGuideId() != null ? dto.getGuideId() : UUID.randomUUID().toString()); // DTO에 ID가 없을 경우 새로운 UUID 생성
        entity.setGname(dto.getGname());
        entity.setGename(dto.getGename());
        entity.setGdescription(dto.getGdescription());
        entity.setGvideoUrl(dto.getGvideoUrl());
        entity.setGbodyPart(dto.getGbodyPart());
        entity.setGimageLink(dto.getGimageLink());
        entity.setGdetailLink(dto.getGdetailLink());

        return entity;
    }
}
