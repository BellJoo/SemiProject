package com.icia.semi.service;

import com.icia.semi.dao.BoardRepository;
import com.icia.semi.dao.CommentRepository;
import com.icia.semi.dao.LikeRepository;
import com.icia.semi.dto.BoardDTO;
import com.icia.semi.dto.BoardEntity;
import com.icia.semi.dto.SearchDTO;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.aspectj.weaver.tools.cache.SimpleCacheFactory.path;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final CommentRepository mrepo;
    private final CommentRepository crepo;
    private final BoardRepository brepo;
    private final LikeRepository lrepo;
    private final HttpServletRequest request;
    private final HttpServletResponse response;
    private final HttpSession session;
    private ModelAndView mav;

    private final Path uploadDir = Paths.get(System.getProperty("user.dir"), "src/main/resources/static/upload");

    public ModelAndView bWrite(BoardDTO board) {
        mav = new ModelAndView();
        MultipartFile fileData = board.getFileData();
        String savePath = "";

        if (!fileData.isEmpty()) {
            String uuid = UUID.randomUUID().toString().substring(0, 8);
            String fileName = fileData.getOriginalFilename();
            String fileNameWithUuid = uuid + "_" + fileName;
            board.setFileName(fileNameWithUuid);
            savePath = uploadDir + File.separator + fileNameWithUuid;

            try {
                fileData.transferTo(new File(savePath));
            } catch (IOException e) {
                System.out.println("파일 업로드 실패: " + e.getMessage());
            }
        } else {
            board.setFileName("default.jpg");
        }

        BoardEntity entity = BoardEntity.toEntity(board);
        brepo.save(entity);
        mav.setViewName("redirect:/index");
        return mav;
    }

    public List<BoardDTO> boardList() {
        List<BoardDTO> dtoList = new ArrayList<>();
        List<BoardEntity> entityList = brepo.findAllByOrderByBoardIdDesc();
        for (BoardEntity entity : entityList) {
            dtoList.add(BoardDTO.toDTO(entity));
        }
        return dtoList;
    }






    public List<BoardDTO> searchList(SearchDTO search) {
        List<BoardDTO> dtoList = new ArrayList<>();
        List<BoardEntity> entityList = new ArrayList<>();

        // 카테고리와 검색어로 필터링
        String category = search.getCategory();
        String keyword = search.getKeyword();
        String searchType = search.getSearchType();

        if (category != null && !category.isEmpty()) {
            if (search.getCategory().equals("free")) {
                entityList = brepo.findByCategoryAndMember_MemberIdContainingOrderByBoardIdDesc(search.getKeyword(), "free");
            } else if (search.getCategory().equals("notice")) {
                entityList = brepo.findByCategoryAndMember_MemberIdContainingOrderByBoardIdDesc(search.getKeyword(), "notice");
            } else if (search.getCategory().equals("question")) {
                entityList = brepo.findByCategoryAndMember_MemberIdContainingOrderByBoardIdDesc(search.getKeyword(), "question");
            } else if (searchType.equals("title")) {
                entityList = brepo.findByCategoryAndTitleContainingOrderByBoardIdDesc(category, keyword);
            } else if (searchType.equals("content")) {
                entityList = brepo.findByCategoryAndContentContainingOrderByBoardIdDesc(category, keyword);
            } else if (searchType.equals("write")) {
                entityList = brepo.findByCategoryAndMember_MemberIdContainingOrderByBoardIdDesc(category, keyword);
            }
        } else { // 카테고리가 없는 경우
            if (search.getCategory().equals("free")) {
                entityList = brepo.findByMember_MemberIdContainingOrderByBoardIdDesc("free");
            } else if (search.getCategory().equals("notice")) {
                entityList = brepo.findByMember_MemberIdContainingOrderByBoardIdDesc("notice");
            } else if (search.getCategory().equals("question")) {
                entityList = brepo.findByMember_MemberIdContainingOrderByBoardIdDesc("question");
            } else if (searchType.equals("title")) {
                entityList = brepo.findByTitleContainingOrderByBoardIdDesc(keyword);
            } else if (searchType.equals("content")) {
                entityList = brepo.findByContentContainingOrderByBoardIdDesc(keyword);
            } else if (searchType.equals("write")) {
                entityList = brepo.findByMember_MemberIdContainingOrderByBoardIdDesc(keyword);
            }
        }

        // DTO 변환
        for (BoardEntity entity : entityList) {
            dtoList.add(BoardDTO.toDTO(entity));
        }

        return dtoList;
    }


    //
//    public ModelAndView view(int boardId) {
//        mav = new ModelAndView();
//        String loginId = (String) session.getAttribute("loginId");
//        if (loginId == null) {
//            loginId = "Guest";
//        }
//
//        Cookie[] cookies = request.getCookies();
//        boolean isViewed = false;
//
//        if (cookies != null) {
//            for (Cookie cookie : cookies) {
//                if (cookie.getName().equals("cookie_" + loginId + "_" + boardId)) {
//                    isViewed = true;
//                    break;
//                }
//            }
//        }
//
//        if (!isViewed) {
//            Cookie newCookie = new Cookie("cookie_" + loginId + "_" + boardId, "viewed");
//            newCookie.setMaxAge(60 * 60);
//            response.addCookie(newCookie);
//            brepo.incrementViews(boardId);
//        }
//
//        Optional<BoardEntity> entity = brepo.findById(boardId);
//        if (entity.isPresent()) {
//            BoardDTO dto = BoardDTO.toDTO(entity.get());
//            mav.addObject("view", dto);
//            mav.setViewName("view");
//        } else {
//            mav.setViewName("redirect:/list");
//        }
//        return mav;
//    }
//
//    public boolean incrementLike(int boardId, String loginId) {
//        if (lrepo.hasUserLiked(boardId, loginId)) {
//            return false;
//        }
//
//        LikeEntity like = new LikeEntity();
//        like.setBoardId(boardId);
//        like.setLoginId(loginId);
//        lrepo.save(like);
//
//        brepo.incrementLikeCount(boardId);
//        return true;
//    }
//
    public ModelAndView bView(int boardId) {
        mav = new ModelAndView();
        String loginId = (String) session.getAttribute("loginId");
        if (loginId == null) {
            loginId = "Guest";
        }

        Cookie[] cookies = request.getCookies();
        boolean isViewed = false;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("cookie_" + loginId + "_" + boardId)) {
                    isViewed = true;
                    break;
                }
            }
        }

        if (!isViewed) {
            Cookie newCookie = new Cookie("cookie_" + loginId + "_" + boardId, "viewed");
            newCookie.setMaxAge(60 * 60);
            response.addCookie(newCookie);
            brepo.incrementViews(boardId);
        }

        Optional<BoardEntity> entity = brepo.findById(boardId);
        if (entity.isPresent()) {
            BoardDTO dto = BoardDTO.toDTO(entity.get());
            mav.addObject("view", dto);
            mav.setViewName("board/view");
        } else {
            mav.setViewName("redirect:/list");
        }
        return mav;
    }

    // 수정
    public ModelAndView bModify(BoardDTO board) {
        System.out.println("[2] controller → service : " + board);
        mav = new ModelAndView();

        // 수정할 게시글 엔티티 가져오기
        Optional<BoardEntity> optionalEntity = brepo.findById(board.getBoardId());
        if (optionalEntity.isPresent()) {
            BoardEntity entity = optionalEntity.get();

            // 제목 및 내용 업데이트
            entity.setTitle(board.getTitle());
            entity.setContent(board.getContent());

            // 파일 수정이 있는 경우
            MultipartFile fileData = board.getFileData();
            if (!fileData.isEmpty()) {
                // 기존 파일 삭제
                if (entity.getFileName() != null && !"default.jpg".equals(entity.getFileName())) {
                    String delPath = uploadDir + File.separator + entity.getFileName();
                    File delFile = new File(delPath);
                    if (delFile.exists() && !delFile.delete()) {
                        System.out.println(entity.getFileName() + " 파일 삭제 실패");
                    }
                }

                // 새로운 파일 저장
                String uuid = UUID.randomUUID().toString().substring(0, 8);
                String fileName = fileData.getOriginalFilename();
                String fileNameWithUuid = uuid + "_" + fileName;
                entity.setFileName(fileNameWithUuid);
                String savePath = uploadDir + File.separator + fileNameWithUuid;

                try {
                    fileData.transferTo(new File(savePath));
                } catch (IOException e) {
                    System.out.println("파일 업로드 실패: " + e.getMessage());
                }
            }

            // 데이터베이스에 수정 사항 저장
            brepo.save(entity);
            mav.setViewName("redirect:/bView/" + board.getBoardId());
        } else {
            mav.setViewName("redirect:/bList");
        }

        return mav;
    }


    // 게시글 삭제
    public ModelAndView bDelete(BoardDTO board) {
        System.out.println("[2] controller → service : " + board);
        mav = new ModelAndView();

        // 기존 파일 삭제하기
        if (board.getFileName() != null && !"default.jpg".equals(board.getFileName())) {
            String delPath = path + "\\" + board.getFileName();
            File delFile = new File(delPath);
            if (delFile.exists() && !delFile.delete()) {
                System.out.println(board.getFileName() + " 파일 삭제 실패");
            }
        }
        brepo.deleteById(board.getBoardId());
        mav.setViewName("redirect:/bList");

        return mav;
    }


//
//    public boolean incrementLike(int boardId, String loginId) {
//        if (lrepo.hasUserLiked(boardId, loginId)) {
//            return false;
//        }
//
//        LikeEntity like = new LikeEntity();
//        like.setBoardId(boardId);
//        like.setLoginId(loginId);
//        lrepo.save(like);
//
//        brepo.incrementLikeCount(boardId);
//        return true;
//    }


    // like(좋아요)
    public boolean incrementLike(int boardId, String loginId) {
        // 사용자가 이미 좋아요를 눌렀는지 확인
        if (lrepo.hasUserLiked(boardId, loginId)) {
            return false; // 이미 좋아요를 누른 상태면 false 반환
        }

        // 새로운 좋아요 정보 저장
        lrepo.saveLike(boardId, loginId);

        // 게시글 조회 후 좋아요 수 증가
        Optional<BoardEntity> optionalBoard = brepo.findByBoardId(boardId);
        optionalBoard.ifPresent(board -> {
            board.setLikes(board.getLikes() + 1); // 좋아요 수 증가
            brepo.save(board); // 변경된 게시글 저장
        });

        return true; // 좋아요 성공
    }

    public int getLikeCount(int boardId) {
        // boardId에 해당하는 게시글의 좋아요 수 반환
        Optional<BoardEntity> board = brepo.findByBoardId(boardId);
        return board.map(BoardEntity::getLikes).orElse(0); // 좋아요 수가 없으면 0 반환
    }

}
