package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;


import java.time.LocalDateTime;
import java.util.List;
@Data
@Entity
@Table(name = "boards")
@SequenceGenerator(name = "B_SEQ_GENERATOR", sequenceName = "B_SEQ", allocationSize = 1)
public class BoardEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "B_SEQ_GENERATOR")
    private int boardId;

    @Column
    private String title;

    @Column(length = 1000)
    private String content;

    @Column(updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(insertable = false)
    private LocalDateTime updatedAt;

    @Column
    private int views;

    @Column
    private String fileName;

    @Column
    private int likes;

    @Column
    private int reportCount;


    @Column
    private String category;


    @ManyToOne
    @JoinColumn(name = "memberId")
    private MemberEntity member;


    @OneToMany(mappedBy = "board", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CommentEntity> comments;



    public static BoardEntity toEntity(BoardDTO dto) {

        BoardEntity entity = new BoardEntity();
        MemberEntity member = new MemberEntity();

        entity.setTitle(dto.getTitle());
        entity.setContent(dto.getContent());
        entity.setCreatedAt(dto.getCreatedAt());
        entity.setUpdatedAt(dto.getUpdatedAt());
        entity.setViews(dto.getViews());
        entity.setFileName(dto.getFileName());
        entity.setLikes(dto.getLikes());
        entity.setReportCount(dto.getReportCount());
        entity.setCategory(dto.getCategory());



        member.setMemberId(dto.getMemberId());
        entity.setMember(member);

        return entity;
    }



    public static BoardEntity toEntity(BoardDTO dto, MemberEntity member) {
        BoardEntity entity = new BoardEntity();
        entity.setTitle(dto.getTitle());
        entity.setContent(dto.getContent());
        entity.setCreatedAt(dto.getCreatedAt());
        entity.setUpdatedAt(dto.getUpdatedAt());
        entity.setViews(dto.getViews());
        entity.setFileName(dto.getFileName());
        entity.setLikes(dto.getLikes());
        entity.setReportCount(dto.getReportCount());
        entity.setCategory(dto.getCategory());



        entity.setMember(member);  // 실제 MemberEntity 설정
        return entity;
    }



}


