package com.icia.semi.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class InquiryDTO {
    private String inquiryId;
    private String memberId;
    private String adminId;
    private String title;
    private String message;
    private String adminReply;
    private String response;
    private LocalDateTime createdAt;

    public static InquiryDTO toDTO(InquiryEntity entity){
        InquiryDTO dto = new InquiryDTO();

        dto.setInquiryId(entity.getInquiryId());
        dto.setTitle(entity.getTitle());
        dto.setMessage(entity.getMessage());
        dto.setAdminReply(entity.getAdminReply());
        dto.setResponse(entity.getResponse());
        dto.setCreatedAt(entity.getCreatedAt());

        dto.setMemberId(entity.getMember().getMemberId());
        dto.setAdminId(entity.getAdmin().getAdminId());

        return dto;
    }
}
