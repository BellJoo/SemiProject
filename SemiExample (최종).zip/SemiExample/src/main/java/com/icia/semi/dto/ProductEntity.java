package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Table(name = "products")
@Data
public class ProductEntity {

    @Id
    @Column(name = "productid", length = 36, nullable = false, updatable = false)
    private String productId;

    @Column(name = "pname", length = 150, nullable = false)
    private String pname;

    @Column(name = "category", length = 100, nullable = false)
    private String category;

    @Column(name = "price", nullable = false)
    private double price;

    @Column(name = "stock", nullable = false)
    private int stock;

    @Column(name = "pimageurl", length = 255)
    private String pimageUrl;

    @Column(name = "createdat", nullable = false, updatable = false)
    private Timestamp createdAt;

    @Column(name = "updatedat")
    private Timestamp updatedAt;

    public ProductEntity() {
        this.createdAt = new Timestamp(System.currentTimeMillis());
    }


    public String getCoverImage() {
        return this.pimageUrl; // pimageUrl을 coverImage로 매핑
    }

}
