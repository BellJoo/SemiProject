// CommentService.java
package com.icia.semi.service;

import com.icia.semi.dao.CommentRepository;
import com.icia.semi.dto.BoardEntity;
import com.icia.semi.dto.CommentDTO;
import com.icia.semi. dto.CommentEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommentService {

    private final CommentRepository crepo;

    // 댓글 목록 조회
    public List<CommentDTO> cList(int boardId) {
        List<CommentDTO> dtoList = new ArrayList<>();
        List<CommentEntity> entityList = crepo.findAllByBoard_BoardId(boardId);

        for (CommentEntity entity : entityList) {
            dtoList.add(CommentDTO.toDTO(entity));
        }
        return dtoList;
    }

    // 댓글 작성
    public List<CommentDTO> cWrite(CommentDTO comment) {
        // DTO를 Entity로 변환하여 저장
        CommentEntity entity = CommentEntity.toEntity(comment);
        crepo.save(entity);

        // 댓글 작성 후 해당 게시글의 댓글 목록 반환
        return cList(comment.getBoardId());
    }

    // 댓글 삭제
    public List<CommentDTO> cDelete(CommentDTO comment) {
        // ID를 이용하여 댓글 삭제
        crepo.deleteById(comment.getCommentId());

        // 댓글 삭제 후 해당 게시글의 댓글 목록 반환
        return cList(comment.getBoardId());
    }


    public void cModify(CommentDTO comment) {
        // 댓글 ID를 통해 기존 댓글 조회
        CommentEntity existingComment = crepo.findById(comment.getCommentId())
                .orElseThrow(() -> new IllegalArgumentException("댓글을 찾을 수 없습니다."));

        // 수정할 내용 설정
        existingComment.setContent(comment.getContent());
        existingComment.setUpdatedAt(LocalDateTime.now());

        // 변경 사항 저장
        crepo.save(existingComment);
    }

}
