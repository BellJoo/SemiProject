package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
@Data
@Entity
@Table(name = "comments")
@SequenceGenerator(name = "C_SEQ_GENERATOR", sequenceName = "C_SEQ", allocationSize = 1)
public class CommentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "C_SEQ_GENERATOR")
    private int commentId;

    @Column
    private String content;

    @Column(updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(insertable = false)
    @org.hibernate.annotations.UpdateTimestamp  // 수정 시점 자동 갱신
    private LocalDateTime updatedAt;

    @ManyToOne
    @JoinColumn(name = "memberId")
    private MemberEntity member;

    @ManyToOne
    @JoinColumn(name = "boardId",nullable = false)
    private BoardEntity board;

    public static CommentEntity toEntity(CommentDTO dto){
        CommentEntity entity = new CommentEntity();

        entity.setContent(dto.getContent());
        entity.setCreatedAt(dto.getCreatedAt());  // DTO에서 받아온 생성일 설정
        entity.setUpdatedAt(dto.getUpdatedAt());  // DTO에서 받아온 수정일 설정

        MemberEntity member = new MemberEntity();
        member.setMemberId(dto.getMemberId());
        entity.setMember(member);

        BoardEntity board = new BoardEntity();
        board.setBoardId(dto.getBoardId());
        entity.setBoard(board);

        return entity;
    }

    public static CommentEntity toEntity(CommentDTO dto, MemberEntity member, BoardEntity board) {
        CommentEntity entity = new CommentEntity();

        entity.setContent(dto.getContent());
        entity.setCreatedAt(dto.getCreatedAt());  // DTO에서 받아온 생성일 설정
        entity.setUpdatedAt(dto.getUpdatedAt());  // DTO에서 받아온 수정일 설정
        entity.setMember(member); // 기존 멤버 엔티티 설정
        entity.setBoard(board);   // 기존 게시판 엔티티 설정

        return entity;
    }

}

