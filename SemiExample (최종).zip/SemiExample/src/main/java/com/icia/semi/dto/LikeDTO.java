package com.icia.semi.dto;

import lombok.Data;

@Data
public class LikeDTO {
    private int likeId;         // likeId 필드 추가
    private int boardId;
    private String loginId;

    public static LikeDTO toDTO(LikeEntity entity){
        LikeDTO dto = new LikeDTO();
        dto.setLikeId(entity.getLikeId());
        dto.setBoardId(entity.getBoardId());
        dto.setLoginId(entity.getLoginId());

        return dto;
    }
}
