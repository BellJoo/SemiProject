package com.icia.semi.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/index")
    public String index() {
        return "index";  // templates/shopping/index.html을 렌더링
    }

    @GetMapping("/about-us")
    public String aboutUs() {
        return "about-us";  // templates/shopping/about-us.html을 렌더링
    }

    @GetMapping("/classes")
    public String classes() {
        return "classes";  // templates/shopping/classes.html을 렌더링
    }

    @GetMapping("/blog")
    public String blog() {
        return "blog";  // templates/shopping/blog.html을 렌더링
    }

    @GetMapping("/gallery")
    public String gallery() {
        return "gallery";  // templates/shopping/gallery.html을 렌더링
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";  // templates/shopping/contact.html을 렌더링
    }

//    @GetMapping("/shopping/cart")
//    public String cartPage() {
//        return "shopping/cart";
//    }
//
//    @GetMapping("/shopping/myPay")
//    public String paymentHistoryPage() {
//        return "shopping/myPay";
//    }



}
