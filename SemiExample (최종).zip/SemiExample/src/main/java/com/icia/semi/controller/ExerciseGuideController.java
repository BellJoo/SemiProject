package com.icia.semi.controller;

import com.icia.semi.dto.ExerciseGuideDTO;
import com.icia.semi.service.ExerciseGuideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ExerciseGuideController {

    @Autowired
    private ExerciseGuideService exerciseGuideService;

    // 특정 운동 부위에 대한 운동 가이드 목록을 가져오는 메서드
//    @GetMapping("/guideInfo/{bodyPart}")
//    public String getGuidesByBodyPart(@PathVariable("bodyPart") String bodyPart, Model model) {
//        List<ExerciseGuideDTO> guides = exerciseGuideService.getGuidesByBodyPart(bodyPart);
//        model.addAttribute("guides", guides);
//        model.addAttribute("bodyPart", bodyPart);
//        return "gym/guideInfo";  // guideInfo.html로 이동
//    }

    // 운동 부위를 기준으로 운동 가이드 목록을 가져오는 메서드 테스트중
//    @GetMapping("/guideInfo")
//    public String getAllGuides(Model model) {
//        model.addAttribute("backGuides", exerciseGuideService.getGuidesByBodyPart("등"));
//        model.addAttribute("chestGuides", exerciseGuideService.getGuidesByBodyPart("가슴"));
//        model.addAttribute("chestTricepsGuides", exerciseGuideService.getGuidesByBodyPart("가슴/삼두"));
//        // 필요 시 다른 부위 추가 가능
//        return "gym/guideInfo";
//    }


    // 운동 부위를 기준으로 운동 가이드 목록을 가져오는 메서드
    @GetMapping("/guideInfo")
    public String getAllGuides(Model model) {
        model.addAttribute("backGuides", exerciseGuideService.getGuidesByBodyPart("등"));
        model.addAttribute("chestGuides", exerciseGuideService.getGuidesByBodyPart("가슴"));
        model.addAttribute("chestTricepsGuides", exerciseGuideService.getGuidesByBodyPart("가슴/삼두"));
        model.addAttribute("thighGuides", exerciseGuideService.getGuidesByBodyPart("대퇴"));
        model.addAttribute("thighCalvesGuides", exerciseGuideService.getGuidesByBodyPart("대퇴/종아리"));
        model.addAttribute("absGuides", exerciseGuideService.getGuidesByBodyPart("복근"));
        model.addAttribute("tricepsAbsGuides", exerciseGuideService.getGuidesByBodyPart("삼두/복근"));
        model.addAttribute("shoulderGuides", exerciseGuideService.getGuidesByBodyPart("어깨"));
        model.addAttribute("bicepGuides", exerciseGuideService.getGuidesByBodyPart("이두"));
        model.addAttribute("calfGuides", exerciseGuideService.getGuidesByBodyPart("종아리"));
        return "gym/guideInfo";
    }




    // 특정 운동 가이드의 상세 정보를 가져오는 메서드
    @GetMapping("/guideDetail/{guideId}")
    public String getGuideDetail(@PathVariable("guideId") String guideId, Model model) {
        ExerciseGuideDTO guideDetail = exerciseGuideService.getGuideDetail(guideId);
        model.addAttribute("guideDetail", guideDetail);
        return "gym/guideDetail";  // guideDetail.html로 이동
    }
}
