package com.icia.semi.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "admins")
public class AdminEntity {

    @Id
    @Column(name = "admin_id")
    private String adminId;    // 관리자 계정명 (Admin_Id -> adminId)

    @Column(name = "username", unique = true, nullable = false)
    private String adminUUId;  // 관리자 고유 아이디 (Admin_UUId -> adminUUId)

    @Column(name = "password", nullable = false)
    private String adminPw;    // 암호화된 비밀번호 (Admin_Pw -> adminPw)

    @Column(name = "name")
    private String adminName;  // 관리자 이름 (Admin_Name -> adminName)

    @Column(name = "email")
    private String adminEmail; // 이메일 (Admin_Email -> adminEmail)

    @Column(name = "phone")
    private String adminPhone; // 연락처 (Admin_Phone -> adminPhone)

    @Column(name = "address")
    private String adminAddress; // 주소 (Admin_Address -> adminAddress)

    @Column(name = "profile")
    private String adminProfileName; // 프로필 이미지 URL (Admin_ProfileName -> adminProfileName)

    @Column(name = "superadmin", nullable = false, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String isSuperAdmin = "N"; // superadmin 여부 (Y/N)

    @Column(name = "manage_inquiries", nullable = false, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String manageInquiries = "N"; // 문의사항 관리 권한 (Y/N)

    @Column(name = "manage_notices", nullable = false, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String manageNotices = "N";  // 공지사항 관리 권한 (Y/N)

    @Column(name = "manage_events", nullable = false, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String manageEvents = "N";   // 이벤트 관리 권한 (Y/N)

    @Column(name = "manage_reports", nullable = false, columnDefinition = "CHAR(1) DEFAULT 'N'")
    private String manageReports = "N";  // 신고 처리 관리 권한 (Y/N)


    @OneToMany(mappedBy = "admin", cascade = CascadeType.ALL)
    private List<InquiryEntity> inquiries;


    // AdminEntity -> AdminDTO 변환
    public static AdminEntity toEntity(AdminDTO dto) {
        AdminEntity entity = new AdminEntity();
        entity.setAdminUUId(dto.getAdminUUId() != null ? dto.getAdminUUId() : UUID.randomUUID().toString()); // UUID 자동 생성
        entity.setAdminId(dto.getAdminId());
        entity.setAdminPw(dto.getAdminPw());
        entity.setAdminName(dto.getAdminName());
        entity.setAdminEmail(dto.getAdminEmail());
        entity.setAdminPhone(dto.getAdminPhone());
        entity.setAdminAddress(dto.getAdminAddress());
        entity.setAdminProfileName(dto.getAdminProfileName());
        // null 체크 및 기본값 설정
        entity.setIsSuperAdmin(dto.getIsSuperAdmin() != null ? dto.getIsSuperAdmin() : "N");  // 기본값 처리
        entity.setManageInquiries(dto.getManageInquiries() != null ? dto.getManageInquiries() : "N");  // 기본값 처리
        entity.setManageNotices(dto.getManageNotices() != null ? dto.getManageNotices() : "N");  // 기본값 처리
        entity.setManageEvents(dto.getManageEvents() != null ? dto.getManageEvents() : "N");  // 기본값 처리
        entity.setManageReports(dto.getManageReports() != null ? dto.getManageReports() : "N");  // 기본값 처리
        return entity;
    }

    // AdminEntity -> AdminDTO로 변환하는 메소드
    public AdminDTO toDTO() {
        AdminDTO dto = new AdminDTO();
        dto.setAdminUUId(this.getAdminUUId());
        dto.setAdminId(this.getAdminId());
        dto.setAdminPw(this.getAdminPw());
        dto.setAdminName(this.getAdminName());
        dto.setAdminEmail(this.getAdminEmail());
        dto.setAdminPhone(this.getAdminPhone());
        dto.setAdminAddress(this.getAdminAddress());
        dto.setAdminProfileName(this.getAdminProfileName());
        // null 체크 및 기본값 설정
        dto.setIsSuperAdmin(this.getIsSuperAdmin() != null ? this.getIsSuperAdmin() : "N");
        dto.setManageInquiries(this.getManageInquiries() != null ? this.getManageInquiries() : "N");  // 기본값 처리
        dto.setManageNotices(this.getManageNotices() != null ? this.getManageNotices() : "N");  // 기본값 처리
        dto.setManageEvents(this.getManageEvents() != null ? this.getManageEvents() : "N");  // 기본값 처리
        dto.setManageReports(this.getManageReports() != null ? this.getManageReports() : "N");  // 기본값 처리
        return dto;
    }
}
